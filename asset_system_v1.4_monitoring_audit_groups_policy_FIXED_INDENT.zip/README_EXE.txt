1) 실행
- (가상환경 권장) pip install -r requirements.txt
- python app.py

2) EXE 변환 (PyInstaller)
- pip install pyinstaller
- 프로젝트 루트에서:
  pyinstaller --noconsole --onefile app.py

3) 정적/템플릿 포함 필요(중요)
- 이 프로젝트는 templates/ 와 static/ 폴더를 사용합니다.
- onefile로 묶으면 파일 경로가 바뀌므로, 배포는 아래 2가지 중 하나 추천:

A) onefolder 권장
  pyinstaller --noconsole app.py
  (dist/app 폴더에 templates/static 포함 복사)

B) onefile 유지하려면
  pyinstaller --noconsole --onefile ^
    --add-data "templates;templates" ^
    --add-data "static;static" app.py

4) 업로드 파일(매뉴얼)은 실행 폴더의 uploads/manuals/ 아래 저장됩니다.
