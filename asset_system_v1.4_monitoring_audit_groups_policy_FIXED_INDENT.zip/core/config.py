import os
import sys

def get_base_dir() -> str:
    # PyInstaller / 일반 실행 / 주피터 대응
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    # core/ 디렉토리에서 한 단계 위로
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BASE_DIR = get_base_dir()
STATIC_DIR = os.path.join(BASE_DIR, "static")
DB_PATH = os.path.join(BASE_DIR, "assets.db")
BACKUP_DIR = os.path.join(BASE_DIR, "backups")

def ensure_dirs(base_dir: str) -> None:
    os.makedirs(os.path.join(base_dir, "templates"), exist_ok=True)
    os.makedirs(os.path.join(base_dir, "static", "css"), exist_ok=True)
    os.makedirs(os.path.join(base_dir, "static", "js"), exist_ok=True)
    os.makedirs(os.path.join(base_dir, "static", "vendor"), exist_ok=True)
    os.makedirs(BACKUP_DIR, exist_ok=True)
