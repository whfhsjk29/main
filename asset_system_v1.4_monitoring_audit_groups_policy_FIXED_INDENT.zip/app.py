import os, sys, threading, ipaddress, webbrowser, sqlite3, json, secrets, re, functools, time, mimetypes
from datetime import datetime, timedelta
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from flask import (Flask, jsonify, request, render_template, session,
                   send_file, redirect, url_for, Response)

from core.config import get_base_dir, ensure_dirs, STATIC_DIR, DB_PATH, BACKUP_DIR
from core.db import init_db, get_conn
from core.validator import SecurityValidator
from core.manager import SecurityAssetManager


# ──────────────────── helpers ────────────────────
def safe_filename(name: str) -> str:
    if not name:
        return "unnamed"
    base, ext = os.path.splitext(name)
    base = re.sub(r'[^\w가-힣\-.]', '_', base)
    ext = re.sub(r'[^\w.]', '', ext)
    base = base.strip('_').strip() or "unnamed"
    return f"{base}{ext}" if ext else base


# ──────────────────── 로그인 시도 제한 ────────────────────
_login_attempts = {}   # {ip: [timestamp, ...]}
LOGIN_MAX_ATTEMPTS = 5
LOGIN_LOCKOUT_SEC = 300  # 5분


def _check_login_rate(ip):
    now = time.time()
    attempts = _login_attempts.get(ip, [])
    attempts = [t for t in attempts if now - t < LOGIN_LOCKOUT_SEC]
    _login_attempts[ip] = attempts
    return len(attempts) < LOGIN_MAX_ATTEMPTS


def _record_login_attempt(ip):
    _login_attempts.setdefault(ip, []).append(time.time())


def create_app() -> Flask:
    base_dir = get_base_dir()
    ensure_dirs(base_dir)

    app = Flask(
        __name__,
        static_folder=STATIC_DIR,
        static_url_path="/static",
        template_folder=os.path.join(base_dir, "templates"),
    )
    app.secret_key = SecurityValidator.random_secret()
    app.config["JSON_AS_ASCII"] = False
    app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB 업로드 제한
    app.config["PERMANENT_SESSION_LIFETIME"] = 86400  # 24h
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

    init_db(DB_PATH, BACKUP_DIR)
    manager = SecurityAssetManager(DB_PATH)

    UPLOAD_ROOT = os.path.join(base_dir, "uploads")
    MANUAL_DIR = os.path.join(UPLOAD_ROOT, "manuals")
    os.makedirs(MANUAL_DIR, exist_ok=True)

    ALLOWED_MANUAL_EXT = {
        ".pdf",".png",".jpg",".jpeg",".gif",
        ".txt",".csv",".log",".md",".html",
        ".xlsx",".xls",".docx",".pptx",".hwp",".hwpx",
    }

    # ════════════════════════════════════════════
    #  DB 초기화 + 마이그레이션
    # ════════════════════════════════════════════
    def _get_table_columns(conn, table_name):
        rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
        return {r[1] for r in rows}

    def _init_extra_tables():
        conn = get_conn(DB_PATH)
        try:
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("""CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
            conn.execute("""CREATE TABLE IF NOT EXISTS software (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_id TEXT NOT NULL, sw_type TEXT DEFAULT '',
                sw_name TEXT NOT NULL, sw_version TEXT DEFAULT '',
                created_at TEXT DEFAULT (datetime('now')))""")
            conn.execute("""CREATE TABLE IF NOT EXISTS manuals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_id TEXT NOT NULL, doc_name TEXT NOT NULL DEFAULT '',
                file_name TEXT NOT NULL DEFAULT '',
                file_path TEXT NOT NULL DEFAULT '',
                created_at TEXT DEFAULT (datetime('now')))""")
            conn.execute("""CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_id TEXT, action TEXT NOT NULL,
                detail TEXT DEFAULT '', user TEXT DEFAULT '',
                created_at TEXT DEFAULT (datetime('now')))""")
            conn.execute("""CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                display_name TEXT DEFAULT '',
                role TEXT DEFAULT 'user',
                is_active INTEGER DEFAULT 1,
                last_login TEXT DEFAULT '',
                pw_changed_at TEXT DEFAULT (datetime('now')),
                created_at TEXT DEFAULT (datetime('now')))""")

            # 마이그레이션
            existing = _get_table_columns(conn, "manuals")
            if "file_name" not in existing:
                conn.execute("ALTER TABLE manuals ADD COLUMN file_name TEXT NOT NULL DEFAULT ''")
            if "file_path" not in existing:
                conn.execute("ALTER TABLE manuals ADD COLUMN file_path TEXT NOT NULL DEFAULT ''")
            if "doc_name" not in existing:
                conn.execute("ALTER TABLE manuals ADD COLUMN doc_name TEXT NOT NULL DEFAULT ''")

            audit_cols = _get_table_columns(conn, "audit_log")
            if "user" not in audit_cols:
                conn.execute("ALTER TABLE audit_log ADD COLUMN user TEXT DEFAULT ''")

            user_cols = _get_table_columns(conn, "users")
            if "is_active" not in user_cols:
                conn.execute("ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1")
            if "last_login" not in user_cols:
                conn.execute("ALTER TABLE users ADD COLUMN last_login TEXT DEFAULT ''")
            if "pw_changed_at" not in user_cols:
                conn.execute("ALTER TABLE users ADD COLUMN pw_changed_at TEXT DEFAULT ''")

            # 기본 admin 계정 생성
            admin = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()
            if not admin:
                conn.execute(
                    "INSERT INTO users(username, password_hash, display_name, role) VALUES(?,?,?,?)",
                    ("admin", generate_password_hash("admin123"), "관리자", "admin"),
                )
            conn.commit()
        finally:
            conn.close()

    # ──── 설정 / 감사 ────
    def get_setting(key, default):
        conn = get_conn(DB_PATH)
        try:
            row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
            if not row:
                return default
            try:
                return json.loads(row[0])
            except Exception:
                return row[0]
        finally:
            conn.close()

    def set_setting(key, value):
        v = json.dumps(value, ensure_ascii=False)
        conn = get_conn(DB_PATH)
        try:
            conn.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, v))
            conn.commit()
        finally:
            conn.close()


def _ip_in_allowed(ip: str, allowed: list) -> bool:
    if not allowed:
        return True
    try:
        ip_obj = ipaddress.ip_address(ip)
    except Exception:
        return False
    for item in allowed:
        try:
            item = (item or "").strip()
            if not item:
                continue
            if "/" in item:
                net = ipaddress.ip_network(item, strict=False)
                if ip_obj in net:
                    return True
            else:
                if ip_obj == ipaddress.ip_address(item):
                    return True
        except Exception:
            continue
    return False

    def write_audit(asset_id, action, detail=""):
        user = session.get("username", "system")
        conn = get_conn(DB_PATH)
        try:
            conn.execute("INSERT INTO audit_log(asset_id,action,detail,user) VALUES(?,?,?,?)",
                         (asset_id or "", action, detail[:500], user))
            conn.commit()
        finally:
            conn.close()

    _init_extra_tables()

    # ════════════════════════════════════════════
    #  인증 시스템 (강화)
    # ════════════════════════════════════════════
    def login_required(f):
        @functools.wraps(f)
        def wrapped(*args, **kwargs):
            if not session.get("logged_in"):
                if request.is_json or request.path.startswith("/api/"):
                    return jsonify({"ok": False, "error": "로그인이 필요합니다"}), 401
                return redirect(url_for("login_page"))
            return f(*args, **kwargs)
        return wrapped

    def admin_required(f):
        @functools.wraps(f)
        def wrapped(*args, **kwargs):
            if not session.get("logged_in"):
                return jsonify({"ok": False, "error": "로그인이 필요합니다"}), 401
            if session.get("role") != "admin":
                return jsonify({"ok": False, "error": "관리자 권한이 필요합니다"}), 403
            return f(*args, **kwargs)
        return wrapped

    @app.get("/login")
    def login_page():
        if session.get("logged_in"):
            return redirect(url_for("index"))
        return render_template("login.html")

    @app.post("/api/login")
    def api_login():
        ip = request.remote_addr or "unknown"
        if not _check_login_rate(ip):
            remaining = int(LOGIN_LOCKOUT_SEC - (time.time() - min(_login_attempts.get(ip, [time.time()]))))
            return jsonify({"ok": False, "error": f"로그인 시도 초과. {max(remaining,1)}초 후 다시 시도해주세요"}), 429

        body = request.get_json(force=True) or {}
        username = (body.get("username") or "").strip()
        password = body.get("password") or ""
        if not username or not password:
            return jsonify({"ok": False, "error": "아이디와 비밀번호를 입력하세요"}), 400

        conn = get_conn(DB_PATH)
        try:
            row = conn.execute(
                "SELECT id,username,password_hash,display_name,role,is_active FROM users WHERE username=?",
                (username,)).fetchone()
        finally:
            conn.close()

        if not row or not check_password_hash(row[2], password):
            _record_login_attempt(ip)
            write_audit(None, "LOGIN_FAIL", f"실패: {username} from {ip}")
            return jsonify({"ok": False, "error": "아이디 또는 비밀번호가 올바르지 않습니다"}), 401

        if row[5] == 0:
            return jsonify({"ok": False, "error": "비활성화된 계정입니다. 관리자에게 문의하세요"}), 403

        session.permanent = True
        sec=get_setting('security_settings',{});
        try:
            st=int(sec.get('session_timeout_min',60)) if isinstance(sec,dict) else 60
        except Exception:
            st=60
        app.permanent_session_lifetime = timedelta(minutes=st)

        session["logged_in"] = True
        session["user_id"] = row[0]
        session["username"] = row[1]
        session["display_name"] = row[3] or row[1]
        session["role"] = row[4]
        session["login_time"] = datetime.now().isoformat()

        conn = get_conn(DB_PATH)
        try:
            conn.execute("UPDATE users SET last_login=datetime('now') WHERE id=?", (row[0],))
            conn.commit()
        finally:
            conn.close()

        write_audit(None, "LOGIN", f"{username} 로그인 (IP: {ip})")
        return jsonify({"ok": True, "username": row[1], "display_name": row[3], "role": row[4]})

    @app.post("/api/logout")
    def api_logout():
        write_audit(None, "LOGOUT", f"{session.get('username','')} 로그아웃")
        session.clear()
        return jsonify({"ok": True})

    @app.get("/api/me")
    @login_required
    def api_me():
        return jsonify({
            "ok": True,
            "username": session.get("username"),
            "display_name": session.get("display_name"),
            "role": session.get("role"),
        })

    # ──── 사용자 관리 (admin) ────
    @app.get("/api/users")
    @admin_required
    def api_list_users():
        conn = get_conn(DB_PATH)
        try:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT id,username,display_name,role,is_active,last_login,created_at FROM users ORDER BY id").fetchall()
            return jsonify({"ok": True, "items": [dict(r) for r in rows]})
        finally:
            conn.close()

    @app.post("/api/users")
    @admin_required
    def api_add_user():
        body = request.get_json(force=True) or {}
        username = (body.get("username") or "").strip()
        password = body.get("password") or ""
        display_name = (body.get("display_name") or username).strip()
        role = body.get("role", "user")
        if not username or not password:
            return jsonify({"ok": False, "error": "아이디/비밀번호 필수"}), 400
        sec=get_setting('security_settings',{}); minlen=int(sec.get('pw_min_len',8) if isinstance(sec,dict) else 8)
        if len(password) < minlen:
            return jsonify({"ok": False, "error": "비밀번호는 4자 이상"}), 400
        if role not in ("admin", "user", "viewer"):
            role = "user"
        conn = get_conn(DB_PATH)
        try:
            exists = conn.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
            if exists:
                return jsonify({"ok": False, "error": "이미 존재하는 아이디입니다"}), 400
            conn.execute(
                "INSERT INTO users(username, password_hash, display_name, role) VALUES(?,?,?,?)",
                (username, generate_password_hash(password), display_name, role))
            conn.commit()
            write_audit(None, "USER_ADD", f"사용자 추가: {username} ({role})")
            return jsonify({"ok": True})
        finally:
            conn.close()

    @app.delete("/api/users/<int:uid>")
    @admin_required
    def api_delete_user(uid):
        if uid == session.get("user_id"):
            return jsonify({"ok": False, "error": "자기 자신은 삭제할 수 없습니다"}), 400
        conn = get_conn(DB_PATH)
        try:
            conn.execute("DELETE FROM users WHERE id=?", (uid,))
            conn.commit()
            return jsonify({"ok": True})
        finally:
            conn.close()

    @app.patch("/api/users/<int:uid>")
    @admin_required
    def api_patch_user(uid):
        body = request.get_json(force=True) or {}
        conn = get_conn(DB_PATH)
        try:
            if "is_active" in body:
                conn.execute("UPDATE users SET is_active=? WHERE id=?", (1 if body["is_active"] else 0, uid))
            if "role" in body and body["role"] in ("admin","user","viewer"):
                conn.execute("UPDATE users SET role=? WHERE id=?", (body["role"], uid))
            if "display_name" in body:
                conn.execute("UPDATE users SET display_name=? WHERE id=?", (body["display_name"].strip(), uid))
            conn.commit()
            return jsonify({"ok": True})
        finally:
            conn.close()

    @app.patch("/api/users/<int:uid>/password")
    @login_required
    def api_change_password(uid):
        if session.get("role") != "admin" and uid != session.get("user_id"):
            return jsonify({"ok": False, "error": "권한 없음"}), 403
        body = request.get_json(force=True) or {}
        new_pw = body.get("password", "")
        sec=get_setting('security_settings',{}); minlen=int(sec.get('pw_min_len',8) if isinstance(sec,dict) else 8)
        if len(new_pw) < minlen:
            return jsonify({"ok": False, "error": "비밀번호는 4자 이상"}), 400
        conn = get_conn(DB_PATH)
        try:
            conn.execute("UPDATE users SET password_hash=?, pw_changed_at=datetime('now') WHERE id=?",
                         (generate_password_hash(new_pw), uid))
            conn.commit()
            write_audit(None, "PW_CHANGE", f"비밀번호 변경: user_id={uid}")
            return jsonify({"ok": True})
        finally:
            conn.close()

    # ════════════════════════════════════════════
    #  CSRF / 메인 페이지
    # ════════════════════════════════════════════
    @app.before_request
    def _check_auth():
        exempt = ("/login", "/api/login", "/static/", "/favicon")
        if any(request.path.startswith(p) for p in exempt):
            return

        # IP 제한(관리자/설정/메시지/모니터링 등)
        sec = get_setting('security_settings', {})
        allowed_ips = sec.get('allowed_ips', []) if isinstance(sec, dict) else []
        ip = request.remote_addr or ''
        if allowed_ips and (request.path.startswith('/api/') or request.path.startswith('/')):
            if not _ip_in_allowed(ip, allowed_ips):
                return jsonify({'ok': False, 'error': '허용되지 않은 IP입니다'}), 403
        if not session.get("logged_in"):
            if request.path.startswith("/api/"):
                return jsonify({"ok": False, "error": "로그인 필요"}), 401
            return redirect(url_for("login_page"))

    @app.after_request
    def _security_headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "SAMEORIGIN"
        return resp

    @app.get("/")
    def index():
        csrf = SecurityValidator.get_csrf(session)
        title = manager.get_title()
        return render_template("index.html", title=title, csrf=csrf,
                               fields=manager.fields,
                               user=session.get("display_name", ""),
                               role=session.get("role", "user"))

    def require_csrf():
        token = request.headers.get("X-CSRF-Token", "")
        if not SecurityValidator.check_csrf(session, token):
            return jsonify({"ok": False, "error": "CSRF token invalid"}), 403
        return None

    # ════════════════════════════════════════════
    #  데이터 조회 / 자산 CRUD
    # ════════════════════════════════════════════
    @app.get("/api/bootstrap")
    def api_bootstrap():
        assets = manager.get_all_assets()
        edges = manager.get_all_connections()
        nodes = manager.build_vis_nodes(assets)
        return jsonify({"ok": True, "assets": assets, "visNodes": nodes,
                        "visEdges": edges, "title": manager.get_title()})

    @app.post("/api/assets")
    def api_add_asset():
        r = require_csrf()
        if r: return r
        payload = request.get_json(force=True) or {}
        try:
            new_id = manager.add_asset(payload)
        except ValueError as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        write_audit(new_id, "CREATE", json.dumps(payload, ensure_ascii=False)[:500])
        return jsonify({"ok": True, "id": new_id})

    @app.get("/api/assets/<asset_id>")
    def api_get_asset(asset_id):
        """단일 자산 상세 조회"""
        asset = manager.get_asset_by_id(asset_id)
        if not asset:
            return jsonify({"ok": False, "error": "자산을 찾을 수 없습니다"}), 404
        return jsonify({"ok": True, "asset": asset})

    @app.patch("/api/assets/<asset_id>")
    def api_update_field(asset_id):
        r = require_csrf()
        if r: return r
        payload = request.get_json(force=True) or {}
        field = payload.get("field")
        value = payload.get("value", "")
        ok, err = manager.update_asset_field(asset_id, field, value)
        if not ok:
            return jsonify({"ok": False, "error": err or "update failed"}), 400
        write_audit(asset_id, "UPDATE", f"{field} → {value}")
        return jsonify({"ok": True})

    @app.delete("/api/assets/<asset_id>")
    def api_delete_asset(asset_id):
        r = require_csrf()
        if r: return r
        assets = manager.get_all_assets()
        a = next((x for x in assets if x.get("id") == asset_id), None)
        detail = json.dumps(a, ensure_ascii=False)[:500] if a else asset_id
        manager.delete_asset(asset_id)
        write_audit(asset_id, "DELETE", detail)
        return jsonify({"ok": True})

    # ★ 자산 복제
    @app.post("/api/assets/<asset_id>/clone")
    def api_clone_asset(asset_id):
        r = require_csrf()
        if r: return r
        assets = manager.get_all_assets()
        src = next((x for x in assets if x.get("id") == asset_id), None)
        if not src:
            return jsonify({"ok": False, "error": "원본 자산을 찾을 수 없습니다"}), 404
        clone = {k: v for k, v in src.items() if k != "id"}
        name = clone.get("자산명") or clone.get("asset_name") or ""
        clone["자산명"] = f"{name} (복제)"
        mno = clone.get("관리번호") or clone.get("manage_no") or ""
        clone["관리번호"] = f"{mno}_copy"
        new_id = manager.add_asset(clone)
        write_audit(new_id, "CLONE", f"원본: {asset_id}")
        return jsonify({"ok": True, "id": new_id})

    # ──── 연결 ────
    @app.post("/api/connections")
    def api_connect_assets():
        r = require_csrf()
        if r: return r
        payload = request.get_json(force=True) or {}
        ok, err = manager.connect_assets(payload.get("source"), payload.get("target"),
                                          payload.get("label", "연결됨"))
        if not ok:
            return jsonify({"ok": False, "error": err or "connect failed"}), 400
        write_audit(payload.get("source"), "CONNECT", f"{payload.get('source')} → {payload.get('target')}")
        return jsonify({"ok": True})

    @app.delete("/api/connections")
    def api_disconnect_assets():
        r = require_csrf()
        if r: return r
        payload = request.get_json(force=True) or {}
        ok, err = manager.disconnect_assets(payload.get("source"), payload.get("target"))
        if not ok:
            return jsonify({"ok": False, "error": err or "disconnect failed"}), 400
        write_audit(payload.get("source"), "DISCONNECT", f"{payload.get('source')} ↔ {payload.get('target')}")
        return jsonify({"ok": True})

    @app.patch("/api/title")
    def api_update_title():
        r = require_csrf()
        if r: return r
        payload = request.get_json(force=True) or {}
        manager.update_title(payload.get("title", ""))
        return jsonify({"ok": True})

    # ════════════════════════════════════════════
    #  엑셀 업로드 (검증 + 일괄 등록)
    # ════════════════════════════════════════════
    @app.post("/api/import/excel/validate")
    def api_validate_excel():
        r = require_csrf()
        if r: return r
        items = request.get_json(force=True) or []
        return jsonify(manager.validate_assets_payloads(items))

    @app.post("/api/import/excel")
    def api_upload_excel():
        r = require_csrf()
        if r: return r
        items = request.get_json(force=True) or []
        result = manager.add_assets_bulk(items)
        write_audit(None, "IMPORT", f"엑셀 업로드: inserted={result.get('inserted')} skipped={result.get('skipped')}")
        return jsonify(result)

    @app.post("/api/backup")
    def api_backup():
        r = require_csrf()
        if r: return r
        name = manager.create_backup(BACKUP_DIR)
        if not name:
            return jsonify({"ok": False, "error": "backup failed"}), 500
        write_audit(None, "BACKUP", name)
        return jsonify({"ok": True, "file": name})

    # ════════════════════════════════════════════
    #  설정: 컬럼 숨김
    # ════════════════════════════════════════════
    @app.get("/api/settings/columns")
    def api_get_columns_setting():
        return jsonify({"ok": True, "hidden": get_setting("hidden_columns", [])})

    @app.put("/api/settings/columns")
    def api_put_columns_setting():
        r = require_csrf()
        if r: return r
        body = request.get_json(force=True) or {}
        hidden = body.get("hidden", [])
        if not isinstance(hidden, list):
            return jsonify({"ok": False, "error": "hidden must be list"}), 400
        set_setting("hidden_columns", hidden)
        return jsonify({"ok": True})


# ════════════════════════════════════════════
#  설정: 보안 (IP 제한 / 비밀번호 정책 / 세션 타임아웃)
# ════════════════════════════════════════════
@app.route("/api/settings/security", methods=["GET"])
@admin_required
def api_get_security_settings():
    data = get_setting("security_settings", {
        "allowed_ips": [],
        "pw_min_len": 8,
        "pw_change_days": 90,
        "session_timeout_min": 60,
        "sw_license_notify_days": 30,
    })
    return jsonify({"ok": True, "data": data})

@app.route("/api/settings/security", methods=["POST"])
@admin_required
def api_set_security_settings():
    r = require_csrf()
    if r: return r
    body = request.get_json(force=True) or {}
    allowed_ips = body.get("allowed_ips", [])
    if isinstance(allowed_ips, str):
        allowed_ips = [x.strip() for x in allowed_ips.splitlines() if x.strip()]
    if not isinstance(allowed_ips, list):
        return jsonify({"ok": False, "error": "allowed_ips는 list 또는 multiline string 이어야 합니다."}), 400
    try:
        pw_min_len = int(body.get("pw_min_len", 8))
        pw_change_days = int(body.get("pw_change_days", 90))
        session_timeout_min = int(body.get("session_timeout_min", 60))
        sw_license_notify_days = int(body.get("sw_license_notify_days", 30))
    except Exception:
        return jsonify({"ok": False, "error": "숫자 설정값이 올바르지 않습니다."}), 400
    if pw_min_len < 4 or pw_min_len > 64:
        return jsonify({"ok": False, "error": "pw_min_len 범위(4~64)"}), 400
    if pw_change_days < 0 or pw_change_days > 3650:
        return jsonify({"ok": False, "error": "pw_change_days 범위(0~3650)"}), 400
    if session_timeout_min < 5 or session_timeout_min > 1440:
        return jsonify({"ok": False, "error": "session_timeout_min 범위(5~1440)"}), 400

    data = {
        "allowed_ips": allowed_ips,
        "pw_min_len": pw_min_len,
        "pw_change_days": pw_change_days,
        "session_timeout_min": session_timeout_min,
        "sw_license_notify_days": sw_license_notify_days,
    }
    set_setting("security_settings", data)
    return jsonify({"ok": True})

    # ════════════════════════════════════════════
    #  S/W 구성도
    # ════════════════════════════════════════════
    @app.get("/api/assets/<asset_id>/software")
    def api_list_software(asset_id):
        conn = get_conn(DB_PATH)
        try:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT id,sw_type,sw_name,sw_version FROM software WHERE asset_id=? ORDER BY id DESC",
                                (asset_id,)).fetchall()
            return jsonify({"ok": True, "items": [dict(r) for r in rows]})
        finally:
            conn.close()

    @app.post("/api/assets/<asset_id>/software")
    def api_add_software(asset_id):
        r = require_csrf()
        if r: return r
        body = request.get_json(force=True) or {}
        sw_name = (body.get("sw_name") or "").strip()
        if not sw_name:
            return jsonify({"ok": False, "error": "sw_name required"}), 400
        conn = get_conn(DB_PATH)
        try:
            conn.execute("INSERT INTO software(asset_id,sw_type,sw_name,sw_version) VALUES(?,?,?,?)",
                         (asset_id, (body.get("sw_type") or "").strip(), sw_name,
                          (body.get("sw_version") or "").strip()))
            conn.commit()
            write_audit(asset_id, "SW_ADD", f"{sw_name} {body.get('sw_version','')}")
            return jsonify({"ok": True})
        finally:
            conn.close()

    @app.delete("/api/software/<int:sw_id>")
    def api_delete_software(sw_id):
        r = require_csrf()
        if r: return r
        conn = get_conn(DB_PATH)
        try:
            conn.execute("DELETE FROM software WHERE id=?", (sw_id,))
            conn.commit()
            return jsonify({"ok": True})
        finally:
            conn.close()

    @app.get("/api/software/inventory")
    def api_software_inventory():
        sw_name = (request.args.get("sw_name") or "").strip()
        sw_version = (request.args.get("sw_version") or "").strip()
        conn = get_conn(DB_PATH)
        try:
            conn.row_factory = sqlite3.Row
            stats = conn.execute(
                "SELECT sw_name,COALESCE(sw_version,'') as sw_version,COUNT(DISTINCT asset_id) as cnt "
                "FROM software GROUP BY sw_name,COALESCE(sw_version,'') ORDER BY sw_name,sw_version"
            ).fetchall()
            names = [r[0] for r in conn.execute("SELECT DISTINCT sw_name FROM software ORDER BY sw_name").fetchall()]
            versions_by_name = {}
            for n in names:
                vers = conn.execute("SELECT DISTINCT COALESCE(sw_version,'') as v FROM software WHERE sw_name=? ORDER BY v", (n,)).fetchall()
                versions_by_name[n] = [r[0] for r in vers]

            assets = manager.get_all_assets()
            asset_map = {a.get("id"): a for a in assets}
            q = "SELECT asset_id,sw_type,sw_name,COALESCE(sw_version,'') as sw_version FROM software"
            params = []
            conds = []
            if sw_name: conds.append("sw_name=?"); params.append(sw_name)
            if sw_version: conds.append("COALESCE(sw_version,'')=?"); params.append(sw_version)
            if conds: q += " WHERE " + " AND ".join(conds)
            q += " ORDER BY sw_name,sw_version"
            rows = conn.execute(q, params).fetchall()

            out = []
            for r in rows:
                a = asset_map.get(r["asset_id"], {})
                out.append({"asset_id": r["asset_id"],
                            "manage_no": a.get("관리번호", a.get("manage_no", "")),
                            "asset_name": a.get("자산명", a.get("asset_name", "")),
                            "ip": a.get("IP", a.get("ip_addr", "")),
                            "hostname": a.get("Hostname", a.get("hostname", "")),
                            "sw_type": r["sw_type"], "sw_name": r["sw_name"], "sw_version": r["sw_version"]})
            return jsonify({"ok": True, "sw_names": names, "versions_by_name": versions_by_name,
                            "stats": [dict(r) for r in stats], "assets": out})
        finally:
            conn.close()

    # ════════════════════════════════════════════
    #  매뉴얼 (뷰어 + 다운로드 확장자 수정)
    # ════════════════════════════════════════════
    @app.get("/api/assets/<asset_id>/manuals")
    def api_list_manuals(asset_id):
        conn = get_conn(DB_PATH)
        try:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT id,doc_name,file_name FROM manuals WHERE asset_id=? ORDER BY id DESC",
                                (asset_id,)).fetchall()
            return jsonify({"ok": True, "items": [dict(r) for r in rows]})
        finally:
            conn.close()

    @app.post("/api/assets/<asset_id>/manuals/upload")
    def api_upload_manual(asset_id):
        r = require_csrf()
        if r: return r
        if "file" not in request.files:
            return jsonify({"ok": False, "error": "file required"}), 400
        f = request.files["file"]
        if not f.filename:
            return jsonify({"ok": False, "error": "filename required"}), 400

        doc_name = (request.form.get("doc_name") or f.filename).strip()
        filename = safe_filename(f.filename)
        if not filename or filename == "unnamed":
            filename = f"file_{secrets.token_hex(4)}{os.path.splitext(f.filename)[1]}"
        ext = os.path.splitext(filename)[1].lower()
        if ext not in ALLOWED_MANUAL_EXT:
            return jsonify({"ok": False, "error": f"not allowed ext: {ext}"}), 400

        asset_dir = os.path.join(MANUAL_DIR, asset_id)
        os.makedirs(asset_dir, exist_ok=True)
        save_path = os.path.join(asset_dir, filename)
        if os.path.exists(save_path):
            base, ext2 = os.path.splitext(filename)
            filename = f"{base}_{secrets.token_hex(3)}{ext2}"
            save_path = os.path.join(asset_dir, filename)

        f.save(save_path)
        rel_path = os.path.relpath(save_path, base_dir).replace("\\", "/")

        conn = get_conn(DB_PATH)
        try:
            conn.execute("INSERT INTO manuals(asset_id,doc_name,file_name,file_path) VALUES(?,?,?,?)",
                         (asset_id, doc_name, filename, rel_path))
            conn.commit()
            write_audit(asset_id, "MANUAL_ADD", doc_name)
            return jsonify({"ok": True})
        finally:
            conn.close()

    def _manual_row(manual_id):
        conn = get_conn(DB_PATH)
        try:
            return conn.execute("SELECT doc_name,file_name,file_path FROM manuals WHERE id=?",
                                (manual_id,)).fetchone()
        finally:
            conn.close()

    @app.get("/api/manuals/<int:manual_id>/view")
    def api_view_manual(manual_id):
        row = _manual_row(manual_id)
        if not row:
            return jsonify({"ok": False, "error": "not found"}), 404
        file_path = os.path.join(base_dir, row[2].replace("/", os.sep))
        if not os.path.exists(file_path):
            return jsonify({"ok": False, "error": "file missing"}), 404
        filename = row[1]
        ext = os.path.splitext(filename)[1].lower()
        mime_map = {
            ".pdf": "application/pdf", ".png": "image/png",
            ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif",
            ".txt": "text/plain; charset=utf-8", ".csv": "text/csv; charset=utf-8",
            ".log": "text/plain; charset=utf-8", ".md": "text/plain; charset=utf-8",
            ".html": "text/html; charset=utf-8",
        }
        content_type = mime_map.get(ext)
        if content_type:
            return send_file(file_path, mimetype=content_type, as_attachment=False)
        return send_file(file_path, as_attachment=False, download_name=filename)

    @app.get("/api/manuals/<int:manual_id>/download")
    def api_download_manual(manual_id):
        row = _manual_row(manual_id)
        if not row:
            return jsonify({"ok": False, "error": "not found"}), 404
        file_path = os.path.join(base_dir, row[2].replace("/", os.sep))
        if not os.path.exists(file_path):
            return jsonify({"ok": False, "error": "file missing"}), 404
        download_name = row[0]  # doc_name
        original_ext = os.path.splitext(row[1])[1]  # file_name ext
        if not os.path.splitext(download_name)[1] and original_ext:
            download_name = download_name + original_ext
        return send_file(file_path, as_attachment=True, download_name=download_name)

    @app.delete("/api/manuals/<int:manual_id>")
    def api_delete_manual(manual_id):
        r = require_csrf()
        if r: return r
        conn = get_conn(DB_PATH)
        try:
            row = conn.execute("SELECT file_path FROM manuals WHERE id=?", (manual_id,)).fetchone()
            conn.execute("DELETE FROM manuals WHERE id=?", (manual_id,))
            conn.commit()
        finally:
            conn.close()
        if row:
            try:
                os.remove(os.path.join(base_dir, row[0].replace("/", os.sep)))
            except Exception:
                pass
        return jsonify({"ok": True})

    # ════════════════════════════════════════════
    #  대시보드 / 감사 / 내보내기
    # ════════════════════════════════════════════
    @app.get("/api/dashboard")
    def api_dashboard():
        assets = manager.get_all_assets()
        total = len(assets)
        type_counts, net_counts, loc_counts, status_counts = {}, {}, {}, {}
        for a in assets:
            t = a.get("자산유형") or a.get("asset_type") or a.get("group_name") or "기타"
            n = a.get("망구분") or a.get("network_type") or "미분류"
            l = a.get("물리적장소") or a.get("phy_loc") or "미분류"
            ms = a.get("유지보수") or a.get("maint_status") or "미분류"
            type_counts[t] = type_counts.get(t,0)+1
            net_counts[n] = net_counts.get(n,0)+1
            loc_counts[l] = loc_counts.get(l,0)+1
            status_counts[ms] = status_counts.get(ms,0)+1
        conn = get_conn(DB_PATH)
        try:
            sw_total = conn.execute("SELECT COUNT(DISTINCT sw_name) FROM software").fetchone()[0]
            manual_total = conn.execute("SELECT COUNT(*) FROM manuals").fetchone()[0]
            conn_total = conn.execute("SELECT COUNT(*) FROM connections").fetchone()[0]
            recent_changes = conn.execute(
                "SELECT action, COUNT(*) as cnt FROM audit_log WHERE created_at >= datetime('now','-7 days') GROUP BY action ORDER BY cnt DESC"
            ).fetchall()
        finally:
            conn.close()
        return jsonify({"ok": True, "total": total, "type_counts": type_counts,
                        "net_counts": net_counts, "loc_counts": loc_counts,
                        "status_counts": status_counts,
                        "sw_total": sw_total, "manual_total": manual_total,
                        "conn_total": conn_total,
                        "recent_changes": [dict(r) for r in recent_changes]})

    @app.get("/api/audit")
    def api_audit_log():
        limit = min(int(request.args.get("limit", 200)), 1000)
        search = (request.args.get("search") or "").strip()
        action_filter = (request.args.get("action") or "").strip()
        conn = get_conn(DB_PATH)
        try:
            conn.row_factory = sqlite3.Row
            q = "SELECT id,asset_id,action,detail,user,created_at FROM audit_log"
            params = []
            conds = []
            if search:
                conds.append("(asset_id LIKE ? OR detail LIKE ? OR user LIKE ?)")
                params.extend([f"%{search}%"]*3)
            if action_filter:
                conds.append("action=?")
                params.append(action_filter)
            if conds:
                q += " WHERE " + " AND ".join(conds)
            q += " ORDER BY id DESC LIMIT ?"
            params.append(limit)
            rows = conn.execute(q, params).fetchall()
            return jsonify({"ok": True, "items": [dict(r) for r in rows]})
        finally:
            conn.close()

    @app.get("/api/export/full")
    def api_export_full():
        assets = manager.get_all_assets()
        conn = get_conn(DB_PATH)
        try:
            conn.row_factory = sqlite3.Row
            sw_rows = conn.execute("SELECT asset_id,sw_type,sw_name,sw_version FROM software ORDER BY asset_id").fetchall()
        finally:
            conn.close()
        sw_map = {}
        for r in sw_rows:
            sw_map.setdefault(r["asset_id"], []).append(r)
        for a in assets:
            aid = a.get("id", "")
            sw_list = sw_map.get(aid, [])
            a["_sw_list"] = "; ".join(
                f"{s['sw_name']} {s['sw_version']}".strip() + (f" ({s['sw_type']})" if s['sw_type'] else "")
                for s in sw_list
            )
        return jsonify({"ok": True, "assets": assets, "fields": manager.fields})

    return app


def open_browser():
    webbrowser.open("http://127.0.0.1:5000")


if __name__ == "__main__":
    app = create_app()
    # start monitoring background worker
    _stop_evt = threading.Event()
    threading.Thread(target=monitor_worker, args=(_stop_evt,), daemon=True).start()
    threading.Timer(0.6, open_browser).start()
    app.run(host="0.0.0.0", port=5000, debug=False)
def _audit_system(action: str, detail: str = "", asset_id: str = "") -> None:
    try:
        conn = get_conn(DB_PATH)
        conn.execute(
            "INSERT INTO audit_log(asset_id, action, detail, user) VALUES(?,?,?,?)",
            (asset_id or "", action, detail or "", "SYSTEM"),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass

def _send_system_message(receiver: str, subject: str, body: str) -> None:
    if not receiver:
        return
    try:
        conn = get_conn(DB_PATH)
        conn.execute(
            "INSERT INTO messages(sender, receiver, subject, body) VALUES(?,?,?,?)",
            ("SYSTEM", receiver, subject or "", body or ""),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass

def _monitor_receiver_for_asset(asset_row: dict) -> str:
    mode = get_setting("monitor_notify_mode", "account")
    if mode == "assignees":
        # Prefer manager1 -> manager2 -> owner
        for k in ("manager1", "manager2", "owner"):
            v = (asset_row.get(k) or "").strip()
            if v:
                return v
    return get_setting("monitor_notify_account", "admin").strip() or "admin"

def monitor_worker(stop_event: threading.Event) -> None:
    interval = int(get_setting("monitor_interval_sec", "10") or "10")
    threshold = int(get_setting("monitor_fail_threshold", "3") or "3")
    notify_recovery = int(get_setting("monitor_notify_recovery", "1") or "1")

    while not stop_event.is_set():
        try:
            conn = get_conn(DB_PATH)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            targets = cur.execute(
                "SELECT mt.*, a.manager1, a.manager2, a.owner FROM monitoring_targets mt "
                "LEFT JOIN assets a ON a.id=mt.asset_id "
                "WHERE mt.is_enabled=1"
            ).fetchall()

            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            for t in targets:
                t = dict(t)
                ip = (t.get("ip") or "").strip()
                ok = ping_once(ip, 1000)

                fail_count = int(t.get("fail_count") or 0)
                last_status = (t.get("last_status") or "")
                last_alert_state = (t.get("last_alert_state") or "")

                receiver = _monitor_receiver_for_asset(t)

                if ok:
                    # UP
                    new_fail = 0
                    cur.execute(
                        "UPDATE monitoring_targets SET fail_count=?, last_status=?, last_checked_at=? WHERE id=?",
                        (new_fail, "UP", now, t["id"]),
                    )
                    # recovery notice only if previously DOWN and down was alerted
                    if notify_recovery and last_status == "DOWN" and last_alert_state == "DOWN_ALERTED":
                        subj = f"[모니터링 회복] {t['asset_name']} ({ip})"
                        body = f"{t['asset_name']} / {ip} 가 ping 정상으로 회복되었습니다."
                        _send_system_message(receiver, subj, body)
                        cur.execute("UPDATE monitoring_targets SET last_alert_state=? WHERE id=?", ("UP_ALERTED", t["id"]))
                        _audit_system("monitor_recovered", json.dumps({"asset_id": t["asset_id"], "ip": ip}, ensure_ascii=False), asset_id=t["asset_id"])
                else:
                    new_fail = fail_count + 1
                    status = "DOWN" if new_fail >= threshold else (last_status or "")
                    cur.execute(
                        "UPDATE monitoring_targets SET fail_count=?, last_status=?, last_checked_at=?, last_fail_at=? WHERE id=?",
                        (new_fail, status, now, now, t["id"]),
                    )
                    # down alert only once when threshold reached
                    if new_fail == threshold and last_alert_state != "DOWN_ALERTED":
                        subj = f"[모니터링 장애] {t['asset_name']} ({ip})"
                        body = f"{t['asset_name']} / {ip} 가 {threshold}회 연속 ping 실패로 DOWN 처리되었습니다."
                        _send_system_message(receiver, subj, body)
                        cur.execute("UPDATE monitoring_targets SET last_alert_state=? WHERE id=?", ("DOWN_ALERTED", t["id"]))
                        _audit_system("monitor_down", json.dumps({"asset_id": t["asset_id"], "ip": ip}, ensure_ascii=False), asset_id=t["asset_id"])

            conn.commit()
            conn.close()
        except Exception as e:
            try:
                print("[monitor_worker]", e)
            except Exception:
                pass

        # refresh settings occasionally by re-reading each loop
        interval = int(get_setting("monitor_interval_sec", "10") or "10")
        threshold = int(get_setting("monitor_fail_threshold", "3") or "3")
        notify_recovery = int(get_setting("monitor_notify_recovery", "1") or "1")

        stop_event.wait(max(5, interval))



