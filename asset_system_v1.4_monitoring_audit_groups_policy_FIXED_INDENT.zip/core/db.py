import sqlite3
from typing import Optional

def get_conn(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn

def init_db(db_path: str, backup_dir: str) -> None:
    conn = get_conn(db_path)
    cur = conn.cursor()

    # ─── assets ───
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS assets (
            id TEXT PRIMARY KEY,
            no TEXT,
            manage_no TEXT,
            category TEXT,
            network_type TEXT,
            hw_type TEXT,
            asset_type TEXT,
            asset_name TEXT,
            manufacturer TEXT,
            model_name TEXT,
            hostname TEXT,
            ip_addr TEXT,
            rack_loc TEXT,
            rack_no TEXT,
            equip_no TEXT,
            quantity TEXT,
            phy_loc TEXT,
            manager1 TEXT,
            manager2 TEXT,
            maint_company TEXT,
            maint_eng TEXT,
            owner TEXT,
            maint_status TEXT,
            size TEXT,
            serial TEXT,
            os TEXT,
            cpu TEXT,
            memory TEXT,
            disk TEXT,
            project_name TEXT,
            intro_date TEXT,
            price TEXT,
            note TEXT,
            label TEXT,
            group_name TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'active'
        )
        """
    )

    # ─── software / connections ───
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS software (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id TEXT,
            sw_type TEXT,
            sw_name TEXT,
            sw_version TEXT,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
        )
        """
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS connections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_id TEXT,
            target_id TEXT,
            description TEXT,
            UNIQUE(source_id, target_id)
        )
        """
    )

    # ─── files/manuals ───
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS manuals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id TEXT NOT NULL,
            filename TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            file_size INTEGER DEFAULT 0,
            uploaded_by TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
        )
        """
    )

    # ─── users ───
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            last_pw_change TEXT DEFAULT ''
        )
        """
    )

    # ─── settings ───
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
        """
    )
    cur.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('dashboard_title', '보안시스템 자산 관리 시스템')")

    # monitoring policy defaults
    cur.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('monitor_interval_sec', '10')")
    cur.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('monitor_fail_threshold', '3')")
    cur.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('monitor_notify_mode', 'account')")  # account|assignees
    cur.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('monitor_notify_account', 'admin')")
    cur.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('monitor_notify_recovery', '1')")

    # ─── audit log ───
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS audit_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id TEXT DEFAULT '',
            action TEXT NOT NULL,
            detail TEXT DEFAULT '',
            user TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now'))
        )
        """
    )
    cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_log(created_at)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log(action)")

    # ─── notices ───
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS notices(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            body TEXT NOT NULL,
            pinned INTEGER DEFAULT 0,
            created_by TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        )
        """
    )

    # ─── messages ───
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender TEXT NOT NULL,
            receiver TEXT NOT NULL,
            subject TEXT DEFAULT '',
            body TEXT NOT NULL,
            is_read INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now')),
            read_at TEXT DEFAULT ''
        )
        """
    )
    cur.execute("CREATE INDEX IF NOT EXISTS idx_messages_receiver_read ON messages(receiver, is_read)")

    # ─── software licenses ───
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS sw_licenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id TEXT NOT NULL,
            sw_name TEXT NOT NULL,
            license_key TEXT DEFAULT '',
            start_date TEXT DEFAULT '',
            end_date TEXT DEFAULT '',
            notify_days INTEGER DEFAULT 30,
            last_notified_at TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
        )
        """
    )

    # ─── monitoring groups ───
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS monitor_groups(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            created_at TEXT DEFAULT (datetime('now'))
        )
        """
    )

    # ─── monitoring targets ───
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS monitoring_targets(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id TEXT NOT NULL,
            asset_name TEXT NOT NULL,
            ip TEXT NOT NULL,
            group_id INTEGER DEFAULT NULL,
            is_enabled INTEGER DEFAULT 0,
            fail_count INTEGER DEFAULT 0,
            last_status TEXT DEFAULT '',
            last_checked_at TEXT DEFAULT '',
            last_fail_at TEXT DEFAULT '',
            last_alert_state TEXT DEFAULT '',
            extra_fields TEXT DEFAULT '[]',
            UNIQUE(asset_id, ip),
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE,
            FOREIGN KEY(group_id) REFERENCES monitor_groups(id) ON DELETE SET NULL
        )
        """
    )
    cur.execute("CREATE INDEX IF NOT EXISTS idx_monitor_enabled ON monitoring_targets(is_enabled)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_monitor_group ON monitoring_targets(group_id)")

    conn.commit()
    conn.close()

