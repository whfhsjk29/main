/* global vis, XLSX */
const CSRF = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
const FIELDS = window.APP_FIELDS || [];

let STATE = {
  title:'', assets:[], visNodes:[], visEdges:[], network:null,
  settings:{ hiddenColumns:[] },
  sort:{ field:null, dir:'asc' },
  connMap:{},
  view:{ filtered:[], rendered:0, pageSize:200, chunkSize:50, isAppending:false, loaderDropped:false }
};

let _pickedManualFile = null;

function $(id){ return document.getElementById(id); }
function showToast(msg, type='info'){
  const t=$('toast'); if(!t) return;
  t.textContent=msg;
  t.className='toast';
  if(type==='error') t.classList.add('toastError');
  else if(type==='success') t.classList.add('toastSuccess');
  t.hidden=false;
  clearTimeout(showToast._t); showToast._t=setTimeout(()=>t.hidden=true,2500);
}
function setLoading(on){
  const el=$('loading'); if(!el) return;
  el.hidden=!on; el.style.display=on?'flex':'none';
}
function escapeHtml(s){
  return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
    .replaceAll('"','&quot;').replaceAll("'","&#039;");
}

// ──── API ────
async function api(path,{method='GET',body=null}={}){
  const h={'X-CSRF-Token':CSRF};
  if(body!==null) h['Content-Type']='application/json';
  const c=new AbortController(); const t=setTimeout(()=>c.abort(),30000);
  try{
    const res=await fetch(path,{method,headers:h,body:body!==null?JSON.stringify(body):null,signal:c.signal});
    if(res.status===401){ window.location.href='/login'; throw new Error('로그인 필요'); }
    const text=await res.text(); let data={};
    try{data=JSON.parse(text)}catch{data={ok:false,error:(text||'').slice(0,200)||'Invalid JSON'}}
    if(!res.ok||data.ok===false) throw new Error(data.error||`${res.status} ${res.statusText}`);
    return data;
  }catch(err){
    if(err?.name==='AbortError') throw new Error('요청 시간 초과');
    throw err;
  }finally{clearTimeout(t)}
}
async function apiUpload(path,fd){
  const c=new AbortController(); const t=setTimeout(()=>c.abort(),60000);
  try{
    const res=await fetch(path,{method:'POST',headers:{'X-CSRF-Token':CSRF},body:fd,signal:c.signal});
    const text=await res.text(); let data={};
    try{data=JSON.parse(text)}catch{data={ok:false,error:(text||'').slice(0,200)||'Invalid JSON'}}
    if(!res.ok||data.ok===false) throw new Error(data.error||`${res.status}`);
    return data;
  }catch(err){if(err?.name==='AbortError') throw new Error('업로드 시간 초과'); throw err;}
  finally{clearTimeout(t)}
}

function formatDateLoose(s){ if(!s) return ''; const v=String(s).trim(); return v.length===8&&/^\d+$/.test(v)?`${v.slice(0,4)}-${v.slice(4,6)}-${v.slice(6,8)}`:v; }
function formatPrice(v){ if(!v) return ''; const n=Number(String(v).replace(/[^\d]/g,'')); return Number.isNaN(n)?String(v):n.toLocaleString(); }

// ════════════════════════════════════════
//  Tabs
// ════════════════════════════════════════
function initTabs(){
  document.querySelectorAll('.tab').forEach(btn=>{
    btn.addEventListener('click',()=>{
      document.querySelectorAll('.tab').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      const tab=btn.dataset.tab;
      document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));
      const panel=$(`panel-${tab}`);
      if(panel) panel.classList.add('active');
      if(tab==='network'&&!STATE.network) initNetwork();
      if(tab==='software') loadSoftwareInventory();
      if(tab==='rack') renderRackLayout();
      if(tab==='dashboard') loadDashboard();
      if(tab==='audit') loadAuditLog();
    });
  });
}

// ════════════════════════════════════════
//  Table Head (정렬)
// ════════════════════════════════════════
function renderTableHead(){
  const head=$('tableHead');
  head.innerHTML=`<tr>
    <th style="width:44px;text-align:center">No</th>
    <th style="width:100px;text-align:center" class="cellSticky">관리</th>
    ${FIELDS.map(f=>{
      const arrow = STATE.sort.field===f ? (STATE.sort.dir==='asc'?'▲':'▼') : '';
      return `<th data-field="${escapeHtml(f)}" class="sortableHead" data-sort-field="${escapeHtml(f)}">${escapeHtml(f)} <span class="sortArrow">${arrow}</span></th>`;
    }).join('')}
  </tr>`;
  head.querySelectorAll('.sortableHead').forEach(th=>{
    th.style.cursor='pointer';
    th.addEventListener('click',()=>{
      const f=th.dataset.sortField;
      if(STATE.sort.field===f) STATE.sort.dir=STATE.sort.dir==='asc'?'desc':'asc';
      else{ STATE.sort.field=f; STATE.sort.dir='asc'; }
      renderTableHead();
      applySortAndRender();
    });
  });
}

function applySortAndRender(){
  if(STATE.sort.field){
    const f=STATE.sort.field, dir=STATE.sort.dir;
    STATE.view.filtered.sort((a,b)=>{
      let va=String(a[f]||'').toLowerCase(), vb=String(b[f]||'').toLowerCase();
      const na=parseFloat(va.replace(/,/g,'')), nb=parseFloat(vb.replace(/,/g,''));
      if(!isNaN(na)&&!isNaN(nb)) return dir==='asc'?na-nb:nb-na;
      return dir==='asc'?va.localeCompare(vb):vb.localeCompare(va);
    });
  }
  clearTable();
  appendTableRows();
}

// ════════════════════════════════════════
//  Table Row
// ════════════════════════════════════════
function clearTable(){ $('tableBody').innerHTML=''; STATE.view.rendered=0; STATE.view.loaderDropped=false; }

function makeRow(item,rowNo){
  const tr=document.createElement('tr');
  tr.dataset.id=item.id;
  // No
  const tdNo=document.createElement('td'); tdNo.style.textAlign='center'; tdNo.className='cellNo'; tdNo.textContent=String(rowNo); tr.appendChild(tdNo);
  // 관리 버튼
  const tdAct=document.createElement('td'); tdAct.className='cellSticky';
  const wrap=document.createElement('div'); wrap.className='cellActions';
  [
    {act:'detail', icon:'fa-info-circle', title:'상세보기'},
    {act:'edit', icon:'fa-pencil', title:'편집'},
    {act:'copy', icon:'fa-clone', title:'복제'},
    {act:'del', icon:'fa-trash', title:'삭제'},
  ].forEach(({act,icon,title})=>{
    const btn=document.createElement('button'); btn.className='iconMini';
    btn.dataset.act=act; btn.dataset.id=item.id;
    btn.title=title; btn.innerHTML=`<i class="fa ${icon}"></i>`;
    wrap.appendChild(btn);
  });
  tdAct.appendChild(wrap); tr.appendChild(tdAct);

  for(const f of FIELDS){
    const td=document.createElement('td');
    td.className='cellData'; td.dataset.id=item.id; td.dataset.field=f;
    td.setAttribute('data-field',f);
    let val=item[f]||'';
    if(f.includes('도입금액')) val=formatPrice(val);
    if(f.includes('년월')) val=formatDateLoose(val);

    if(f==='관리번호'){
      td.classList.add('cellClickable');
      td.innerHTML=`<span>${escapeHtml(val)}</span><i class="fa fa-cog clickHint" title="S/W 관리"></i>`;
    } else if(f==='자산명'){
      td.classList.add('cellClickable');
      const conns=STATE.connMap[item.id]||[];
      const badge=conns.length?`<span class="connBadge" title="연결: ${conns.map(c=>escapeHtml(c.label)).join(', ')}">${conns.length}</span>`:'';
      td.innerHTML=`<span>${escapeHtml(val)}</span>${badge}<i class="fa fa-file-text-o clickHint" title="매뉴얼/문서"></i>`;
    } else {
      td.textContent=String(val);
    }
    tr.appendChild(td);
  }
  return tr;
}

async function appendTableRows(){
  const v=STATE.view; if(v.isAppending) return; v.isAppending=true;
  try{
    const tbody=$('tableBody'), start=v.rendered;
    const end=Math.min(v.filtered.length,start+v.pageSize);
    for(let s=start;s<end;s+=v.chunkSize){
      const frag=document.createDocumentFragment();
      const sl=v.filtered.slice(s,Math.min(end,s+v.chunkSize));
      sl.forEach((item,i)=>frag.appendChild(makeRow(item,s+i+1)));
      tbody.appendChild(frag);
      if(!v.loaderDropped){v.loaderDropped=true;setLoading(false);}
      await new Promise(r=>setTimeout(r,0));
    }
    v.rendered=end;
    // 건수 표시 업데이트
    const countEl=$('assetCount');
    if(countEl) countEl.textContent=`${v.filtered.length}건`;
  }finally{v.isAppending=false}
}

async function filterAndRender(){
  setLoading(true);
  try{
    const q=$('searchBox').value.trim().toLowerCase();
    const net=$('filterNet').value, type=$('filterType').value;
    const filtered=STATE.assets.filter(a=>{
      const tm=!q||Object.values(a).some(v=>String(v).toLowerCase().includes(q));
      const nm=!net||a['망구분']===net||a.network_type===net;
      const ym=!type||a['자산유형']===type||a.asset_type===type||a.group_name===type;
      return tm&&nm&&ym;
    });
    if(!filtered.length){$('tableBody').innerHTML='';setEmptyState(true);setTableVisible(false);
      const countEl=$('assetCount'); if(countEl) countEl.textContent='0건';
      return;}
    setEmptyState(false); setTableVisible(true);
    STATE.view.filtered=filtered;
    if(STATE.sort.field) applySortAndRender();
    else{clearTable(); await appendTableRows();}
  }finally{setLoading(false)}
}

function bindFilters(){
  $('searchBox').addEventListener('keyup',e=>{if(e.key==='Enter') filterAndRender();});
  // 실시간 필터 (300ms debounce)
  let _searchTimer=null;
  $('searchBox').addEventListener('input',()=>{
    clearTimeout(_searchTimer);
    _searchTimer=setTimeout(()=>filterAndRender(),300);
  });
  $('filterNet').addEventListener('change',filterAndRender);
  $('filterType').addEventListener('change',filterAndRender);
}
function bindInfiniteScroll(){
  const w=document.querySelector('#panel-list .tableWrap'); if(!w) return;
  w.addEventListener('scroll',async()=>{
    const v=STATE.view; if(v.isAppending||v.rendered>=v.filtered.length) return;
    if(w.scrollTop+w.clientHeight>=w.scrollHeight-160) await appendTableRows();
  });
}

function bindCellEditing(){
  const tbody=$('tableBody');
  tbody.addEventListener('dblclick',e=>{
    const td=e.target.closest('td.cellData'); if(!td) return;
    const f=td.dataset.field; if(f==='관리번호'||f==='자산명') return;

    if(f==='자산유형'){
      const options=['방화벽','스위치','L3스위치','서버','DB','보안장비','스토리지','라우터','임의장비','Unknown'];
      const cur=td.innerText.trim();
      const sel=document.createElement('select');
      sel.className='inlineSelect';
      options.forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v;sel.appendChild(o);});
      sel.value=options.includes(cur)?cur:'Unknown';
      td.innerHTML='';
      td.appendChild(sel);
      sel.focus();
      sel.addEventListener('change',()=>sel.blur());
      sel.addEventListener('blur',async()=>{
        const value=sel.value;
        td.innerText=value;
        try{
          await api(`/api/assets/${encodeURIComponent(td.dataset.id)}`,{method:'PATCH',body:{field:f,value}});
          showToast('저장됨','success');
          await reloadBootstrap();
          if(STATE.network) STATE.network.setData({nodes:new vis.DataSet(STATE.visNodes),edges:new vis.DataSet(STATE.visEdges)});
        }catch(err){showToast(`저장 실패: ${err.message}`,'error');}
      });
      return;
    }

    td.classList.add('editable'); td.setAttribute('contenteditable','true'); td.focus();
    const r=document.createRange(); r.selectNodeContents(td); r.collapse(false);
    const s=window.getSelection(); s.removeAllRanges(); s.addRange(r);
  });
  tbody.addEventListener('blur',async e=>{
    const td=e.target.closest('td.cellData[contenteditable="true"]'); if(!td) return;
    let value=td.innerText.trim();
    if(td.dataset.field.includes('금액')) value=value.replace(/,/g,'').trim();
    td.removeAttribute('contenteditable'); td.classList.remove('editable');
    try{
      await api(`/api/assets/${encodeURIComponent(td.dataset.id)}`,{method:'PATCH',body:{field:td.dataset.field,value}});
      showToast('저장됨','success');
    }catch(err){showToast(`저장 실패: ${err.message}`,'error');}
  },true);
  tbody.addEventListener('keydown',e=>{
    const td=e.target.closest('td.cellData[contenteditable="true"]');
    if(td&&e.key==='Enter'){e.preventDefault();td.blur();}
  });
}

function bindCellClickManagement(){
  $('tableBody').addEventListener('click',e=>{
    const td=e.target.closest('td.cellData'); if(!td||td.getAttribute('contenteditable')==='true') return;
    const f=td.dataset.field, id=td.dataset.id;
    if(f==='관리번호') openSoftwareModal(id);
    else if(f==='자산명') openManualModal(id);
  });
}

function bindTableActions(){
  $('tableBody').addEventListener('click',async e=>{
    const btn=e.target.closest('button[data-act]'); if(!btn) return;
    const id=btn.dataset.id;
    if(btn.dataset.act==='del') deleteAsset(id);
    else if(btn.dataset.act==='edit') openAssetModalById(id);
    else if(btn.dataset.act==='copy') cloneAsset(id);
    else if(btn.dataset.act==='detail') openDetailModal(id);
  });
}

async function cloneAsset(id){
  if(!confirm('이 자산을 복제하시겠습니까?')) return;
  setLoading(true);
  try{
    await api(`/api/assets/${encodeURIComponent(id)}/clone`,{method:'POST'});
    showToast('자산 복제 완료','success');
    await reloadBootstrap(); await filterAndRender();
  }catch(err){showToast(`복제 실패: ${err.message}`,'error');}
  finally{setLoading(false)}
}

// ════════════════════════════════════════
//  ★ 자산 상세보기 모달
// ════════════════════════════════════════
async function openDetailModal(assetId){
  const a=STATE.assets.find(x=>x.id===assetId);
  if(!a){showToast('자산을 찾을 수 없습니다','error');return;}
  const modal=$('detailModal'); if(!modal) return;
  const content=$('detailContent'); if(!content) return;

  const conns=STATE.connMap[assetId]||[];
  const swList=(a.software||[]);
  const manualList=(a.manuals||[]);

  let html=`
  <div class="detailGrid">
    <div class="detailSection">
      <h4><i class="fa fa-tag"></i> 기본 정보</h4>
      <div class="detailTable">
        ${[['자산명',a['자산명']||a.asset_name],['관리번호',a['관리번호']||a.manage_no],
           ['자산유형',a['자산유형']||a.asset_type],['분류',a['분류']||a.category],
           ['유형',a['유형']||a.hw_type],['망구분',a['망구분']||a.network_type],
           ['제조사',a['제조사']||a.manufacturer],['모델명',a['모델명']||a.model_name],
        ].map(([k,v])=>`<div class="detailRow"><span class="detailKey">${k}</span><span class="detailVal">${escapeHtml(v||'-')}</span></div>`).join('')}
      </div>
    </div>
    <div class="detailSection">
      <h4><i class="fa fa-server"></i> 네트워크 / 위치</h4>
      <div class="detailTable">
        ${[['Hostname',a['Hostname']||a.hostname],['IP',a['IP']||a.ip_addr],
           ['물리적장소',a['물리적장소']||a.phy_loc],['랙위치',a['랙위치']||a.rack_loc],
           ['랙번호',a['렉 번호']||a.rack_no],['장비크기',a['장비크기']||a.size],
           ['시리얼',a['시리얼']||a.serial],
        ].map(([k,v])=>`<div class="detailRow"><span class="detailKey">${k}</span><span class="detailVal">${escapeHtml(v||'-')}</span></div>`).join('')}
      </div>
    </div>
    <div class="detailSection">
      <h4><i class="fa fa-microchip"></i> 사양</h4>
      <div class="detailTable">
        ${[['OS',a['OS']||a.os],['CPU 코어',a['CPU 코어']||a.cpu],
           ['메모리',a['메모리']||a.memory],['디스크',a['디스크']||a.disk],
        ].map(([k,v])=>`<div class="detailRow"><span class="detailKey">${k}</span><span class="detailVal">${escapeHtml(v||'-')}</span></div>`).join('')}
      </div>
    </div>
    <div class="detailSection">
      <h4><i class="fa fa-users"></i> 관리</h4>
      <div class="detailTable">
        ${[['담당자1',a['담당자1']||a.manager1],['담당자2',a['담당자2']||a.manager2],
           ['유지보수업체',a['유지보수업체']||a.maint_company],['담당엔지니어',a['담당엔지니어']||a.maint_eng],
           ['자산소유',a['자산소유']||a.owner],['유지보수',a['유지보수']||a.maint_status],
           ['도입사업',a['도입사업']||a.project_name],['도입년월',formatDateLoose(a['도입년월']||a.intro_date)],
           ['도입금액',formatPrice(a['도입금액']||a.price)],
        ].map(([k,v])=>`<div class="detailRow"><span class="detailKey">${k}</span><span class="detailVal">${escapeHtml(v||'-')}</span></div>`).join('')}
      </div>
    </div>
  </div>
  <div class="detailBottomRow">
    <div class="detailSection detailSectionFull">
      <h4><i class="fa fa-cubes"></i> 설치 S/W <span class="detailBadge">${swList.length}</span></h4>
      ${swList.length?`<div class="detailChips">${swList.map(s=>`<span class="detailChip"><b>${escapeHtml(s.name||s.sw_name||'')}</b> ${escapeHtml(s.version||s.sw_version||'')}</span>`).join('')}</div>`:'<p class="detailEmpty">등록된 S/W 없음</p>'}
    </div>
    <div class="detailSection detailSectionFull">
      <h4><i class="fa fa-link"></i> 연결 장비 <span class="detailBadge">${conns.length}</span></h4>
      ${conns.length?`<div class="detailChips">${conns.map(c=>`<span class="detailChip">${escapeHtml(c.label)}</span>`).join('')}</div>`:'<p class="detailEmpty">연결 정보 없음</p>'}
    </div>
  </div>
  ${a['비고']||a.note?`<div class="detailSection detailSectionFull"><h4><i class="fa fa-sticky-note"></i> 비고</h4><p class="detailNote">${escapeHtml(a['비고']||a.note)}</p></div>`:''}
  `;

  $('detailModalTitle').textContent=`${a['자산명']||a.asset_name||a.id} 상세 정보`;
  content.innerHTML=html;
  openModal(modal);
}

// ════════════════════════════════════════
//  Network
// ════════════════════════════════════════
function initNetwork(){
  const container=$('network');
  STATE.network=new vis.Network(container,
    {nodes:new vis.DataSet(STATE.visNodes),edges:new vis.DataSet(STATE.visEdges)},
    {nodes:{font:{color:'#fff',size:14},borderWidth:2,shadow:true},
     edges:{color:'#64748b',width:2,font:{color:'#94a3b8',size:10}},
     physics:{stabilization:false,solver:'forceAtlas2Based'},interaction:{hover:true}});
  STATE.network.on('doubleClick',p=>{if(p.nodes?.length) openDetailModal(p.nodes[0]);});
  $('mapFilterNet')?.addEventListener('change',()=>{
    const net=$('mapFilterNet').value;
    STATE.network.setData({nodes:new vis.DataSet(STATE.visNodes.filter(n=>!net||n.zone===net)),edges:new vis.DataSet(STATE.visEdges)});
  });
}
function exportNetworkImage(){
  if(!STATE.network){showToast('네트워크 맵을 먼저 열어주세요','error');return;}
  try{
    const c=document.querySelector('#network canvas'); if(!c){showToast('캔버스 없음','error');return;}
    const a=document.createElement('a'); a.download='네트워크맵.png'; a.href=c.toDataURL('image/png');
    document.body.appendChild(a); a.click(); document.body.removeChild(a); showToast('PNG 저장됨','success');
  }catch(err){showToast(`실패: ${err.message}`,'error');}
}

// ════════════════════════════════════════
//  Modals
// ════════════════════════════════════════
function openOverlay(){$('overlay').hidden=false}
function closeOverlay(){$('overlay').hidden=true}
function openModal(el){openOverlay();el.hidden=false}
function closeModal(el){
  if(!el) return; el.hidden=true;
  const ids=['assetModal','connModal','softwareModal','manualModal','columnsModal','userModal','helpModal','detailModal'];
  if(ids.every(id=>{const m=$(id);return !m||m.hidden})) closeOverlay();
}

function resetAssetModal(){
  ['mName','mIP','mNo','mHost','mLoc','mRackLoc','mRackNo','mUSize','mSerial','mOS','mCPU','mMemory','mDisk',
   'mMfr','mModel','mManager1','mManager2','mMaintCo','mMaintEng','mOwner','mMaint','mProject','mIntroDate','mPrice','mNote'
  ].forEach(id=>{
    if($(id)) $(id).value='';
  });
  $('mType').value='서버'; $('mNet').value=''; $('mCategory').value=''; $('mHwType').value='';
  if($('mUSize')) $('mUSize').value='1';
  $('mEditingId').value='';
}

function openAssetModalById(id){
  const a=STATE.assets.find(x=>x.id===id);
  resetAssetModal();
  if(a){
    $('assetModalTitle').textContent='자산 수정';
    $('mEditingId').value=a.id;
    $('mName').value=a['자산명']||a.asset_name||a.label||'';
    $('mIP').value=a['IP']||a.ip_addr||'';
    $('mType').value=a['자산유형']||a.asset_type||a.group_name||'서버';
    $('mNet').value=a['망구분']||a.network_type||'';
    $('mNo').value=a['관리번호']||a.manage_no||'';
    $('mHost').value=a['Hostname']||a.hostname||'';
    $('mLoc').value=a['물리적장소']||a.phy_loc||'';
    if($('mRackLoc')) $('mRackLoc').value=a['랙위치']||a.rack_loc||'';
    if($('mRackNo')) $('mRackNo').value=a['렉 번호']||a.rack_no||'';
    if($('mUSize')) $('mUSize').value=a['장비크기']||a.size||'1';
    if($('mCategory')) $('mCategory').value=a['분류']||a.category||'';
    if($('mHwType')) $('mHwType').value=a['유형']||a.hw_type||'';
    if($('mMfr')) $('mMfr').value=a['제조사']||a.manufacturer||'';
    if($('mModel')) $('mModel').value=a['모델명']||a.model_name||'';
    if($('mSerial')) $('mSerial').value=a['시리얼']||a.serial||'';
    if($('mOS')) $('mOS').value=a['OS']||a.os||'';
    if($('mCPU')) $('mCPU').value=a['CPU 코어']||a.cpu||'';
    if($('mMemory')) $('mMemory').value=a['메모리']||a.memory||'';
    if($('mDisk')) $('mDisk').value=a['디스크']||a.disk||'';
    if($('mManager1')) $('mManager1').value=a['담당자1']||a.manager1||'';
    if($('mManager2')) $('mManager2').value=a['담당자2']||a.manager2||'';
    if($('mMaintCo')) $('mMaintCo').value=a['유지보수업체']||a.maint_company||'';
    if($('mMaintEng')) $('mMaintEng').value=a['담당엔지니어']||a.maint_eng||'';
    if($('mOwner')) $('mOwner').value=a['자산소유']||a.owner||'';
    if($('mMaint')) $('mMaint').value=a['유지보수']||a.maint_status||'';
    if($('mProject')) $('mProject').value=a['도입사업']||a.project_name||'';
    if($('mIntroDate')) $('mIntroDate').value=a['도입년월']||a.intro_date||'';
    if($('mPrice')) $('mPrice').value=a['도입금액']||a.price||'';
    if($('mNote')) $('mNote').value=a['비고']||a.note||'';
  }else{
    $('assetModalTitle').textContent='자산 등록';
  }
  openModal($('assetModal'));
}

function openConnModal(){
  const src=$('connSrc'),tgt=$('connTgt'); src.innerHTML=''; tgt.innerHTML='';
  STATE.visNodes.forEach(n=>{src.add(new Option(n.label,n.id));tgt.add(new Option(n.label,n.id));});
  $('connLabel').value='연결됨';
  openModal($('connModal'));
}

// ──── S/W 모달 ────
async function openSoftwareModal(assetId){
  const a=STATE.assets.find(x=>x.id===assetId);
  $('swTargetHint').textContent=`대상 장비: ${a?(a['자산명']||a.asset_name||assetId):assetId}`;
  $('swAssetId').value=assetId; $('swName').value=''; $('swVersion').value=''; $('swType').value='';
  openModal($('softwareModal')); await loadSoftwareList(assetId);
}
async function loadSoftwareList(assetId){
  const tbody=$('swList');
  tbody.innerHTML='<tr><td colspan="4" style="text-align:center;color:var(--muted)">로딩 중...</td></tr>';
  try{
    const data=await api(`/api/assets/${encodeURIComponent(assetId)}/software`);
    const items=data.items||[]; tbody.innerHTML='';
    if(!items.length){tbody.innerHTML='<tr><td colspan="4" style="text-align:center;color:var(--muted)">등록된 S/W가 없습니다</td></tr>';return;}
    items.forEach(item=>{
      const tr=document.createElement('tr');
      const tdDel=document.createElement('td'); tdDel.style.textAlign='center';
      const btn=document.createElement('button'); btn.className='iconMini'; btn.innerHTML='<i class="fa fa-trash"></i>';
      btn.addEventListener('click',async()=>{
        if(!confirm('삭제?')) return;
        try{await api(`/api/software/${item.id}`,{method:'DELETE'});showToast('삭제됨','success');await loadSoftwareList(assetId);}catch(e){showToast(e.message,'error');}
      });
      tdDel.appendChild(btn); tr.appendChild(tdDel);
      [item.sw_name,item.sw_version,item.sw_type].forEach(v=>{const td=document.createElement('td');td.textContent=v||'';tr.appendChild(td);});
      tbody.appendChild(tr);
    });
  }catch(err){tbody.innerHTML=`<tr><td colspan="4" style="color:var(--danger)">${escapeHtml(err.message)}</td></tr>`;}
}
async function addSoftware(){
  const assetId=$('swAssetId').value, sw_name=$('swName').value.trim();
  if(!sw_name){showToast('S/W 명을 입력해주세요','error');return;}
  setLoading(true);
  try{
    await api(`/api/assets/${encodeURIComponent(assetId)}/software`,{method:'POST',body:{sw_name,sw_version:$('swVersion').value.trim(),sw_type:$('swType').value.trim()}});
    showToast('S/W 등록 완료','success'); $('swName').value=''; $('swVersion').value=''; $('swType').value='';
    await loadSoftwareList(assetId);
  }catch(err){showToast(`실패: ${err.message}`,'error');}
  finally{setLoading(false)}
}

// ──── 매뉴얼 모달 ────
async function openManualModal(assetId){
  const a=STATE.assets.find(x=>x.id===assetId);
  $('manualTargetHint').textContent=`대상 장비: ${a?(a['자산명']||a.asset_name||assetId):assetId}`;
  $('manualAssetId').value=assetId; $('manualDocName').value=''; $('manualFileName').value='';
  _pickedManualFile=null; $('manualViewer').src='about:blank';
  openModal($('manualModal')); await loadManualList(assetId);
}
async function loadManualList(assetId){
  const tbody=$('manualList');
  tbody.innerHTML='<tr><td colspan="4" style="text-align:center;color:var(--muted)">로딩 중...</td></tr>';
  try{
    const data=await api(`/api/assets/${encodeURIComponent(assetId)}/manuals`);
    const items=data.items||[]; tbody.innerHTML='';
    if(!items.length){tbody.innerHTML='<tr><td colspan="4" style="text-align:center;color:var(--muted)">등록된 문서가 없습니다</td></tr>';return;}
    items.forEach(item=>{
      const tr=document.createElement('tr');
      const tdDel=document.createElement('td'); tdDel.style.textAlign='center';
      const btnDel=document.createElement('button'); btnDel.className='iconMini'; btnDel.innerHTML='<i class="fa fa-trash"></i>';
      btnDel.addEventListener('click',async()=>{
        if(!confirm('삭제?')) return;
        try{await api(`/api/manuals/${item.id}`,{method:'DELETE'});showToast('삭제됨','success');await loadManualList(assetId);}catch(e){showToast(e.message,'error');}
      });
      tdDel.appendChild(btnDel); tr.appendChild(tdDel);
      const tdName=document.createElement('td');
      tdName.textContent=item.doc_name||item.file_name||'(무제)';
      tdName.style.cursor='pointer'; tdName.title=item.file_name||'';
      tr.appendChild(tdName);
      const tdView=document.createElement('td'); tdView.style.textAlign='center';
      const btnView=document.createElement('button'); btnView.className='iconMini';
      btnView.innerHTML='<i class="fa fa-eye"></i>'; btnView.title='미리보기';
      const ext=(item.file_name||'').split('.').pop().toLowerCase();
      const viewableExts=['pdf','png','jpg','jpeg','gif','txt','csv','log','md','html'];
      if(viewableExts.includes(ext)){
        btnView.addEventListener('click',()=>{$('manualViewer').src=`/api/manuals/${item.id}/view`;});
      } else { btnView.disabled=true; btnView.title='미리보기 불가'; btnView.style.opacity='0.3'; }
      tdView.appendChild(btnView); tr.appendChild(tdView);
      const tdDown=document.createElement('td'); tdDown.style.textAlign='center';
      const btnDown=document.createElement('a'); btnDown.className='iconMini';
      btnDown.style.display='inline-flex'; btnDown.style.alignItems='center'; btnDown.style.justifyContent='center';
      btnDown.href=`/api/manuals/${item.id}/download`; btnDown.title='다운로드';
      btnDown.innerHTML='<i class="fa fa-download"></i>';
      tdDown.appendChild(btnDown); tr.appendChild(tdDown);
      tbody.appendChild(tr);
    });
  }catch(err){tbody.innerHTML=`<tr><td colspan="4" style="color:var(--danger)">${escapeHtml(err.message)}</td></tr>`;}
}
async function uploadManual(){
  const assetId=$('manualAssetId').value;
  if(!_pickedManualFile){showToast('파일을 선택해주세요','error');return;}
  const fd=new FormData(); fd.append('file',_pickedManualFile);
  fd.append('doc_name',$('manualDocName').value.trim()||_pickedManualFile.name);
  setLoading(true);
  try{
    await apiUpload(`/api/assets/${encodeURIComponent(assetId)}/manuals/upload`,fd);
    showToast('업로드 완료','success'); $('manualDocName').value=''; $('manualFileName').value='';
    _pickedManualFile=null; $('manualFileInput').value=''; await loadManualList(assetId);
  }catch(err){showToast(`실패: ${err.message}`,'error');}
  finally{setLoading(false)}
}

// ════════════════════════════════════════
//  S/W 인벤토리
// ════════════════════════════════════════
let _swData=[];
async function loadSoftwareInventory(){
  const nameEl=$('swFilterName'),verEl=$('swFilterVersion');
  const sw_name=nameEl?nameEl.value:'', sw_version=verEl?verEl.value:'';
  const statsDiv=$('swStats'),listTbody=$('swAssetList');
  if(statsDiv) statsDiv.innerHTML='<div class="statChip"><b>로딩 중...</b></div>';
  if(listTbody) listTbody.innerHTML='';
  try{
    let url='/api/software/inventory'; const p=[];
    if(sw_name) p.push(`sw_name=${encodeURIComponent(sw_name)}`);
    if(sw_version) p.push(`sw_version=${encodeURIComponent(sw_version)}`);
    if(p.length) url+='?'+p.join('&');
    const data=await api(url);
    if(nameEl){const pv=nameEl.value;nameEl.innerHTML='<option value="">전체 S/W</option>';
      (data.sw_names||[]).forEach(n=>{const o=document.createElement('option');o.value=n;o.textContent=n;nameEl.appendChild(o);});nameEl.value=pv;}
    if(verEl){const pv=verEl.value;verEl.innerHTML='<option value="">전체 버전</option>';
      const vbn=data.versions_by_name||{}, cn=nameEl?nameEl.value:'';
      (cn?(vbn[cn]||[]):[]).forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v||'(없음)';verEl.appendChild(o);});verEl.value=pv;}
    if(statsDiv){statsDiv.innerHTML='';const stats=data.stats||[];
      if(!stats.length) statsDiv.innerHTML='<div class="statChip"><b>등록된 S/W 없음</b></div>';
      else stats.forEach(s=>{const c=document.createElement('div');c.className='statChip';c.innerHTML=`<b>${escapeHtml(s.sw_name)} ${escapeHtml(s.sw_version||'')}</b><span>설치: ${s.cnt}대</span>`;statsDiv.appendChild(c);});}
    _swData=data.assets||[];
    renderSwTable(_swData);
  }catch(err){if(statsDiv) statsDiv.innerHTML=`<div class="statChip"><b style="color:var(--danger)">${escapeHtml(err.message)}</b></div>`;}
}
function renderSwTable(items){
  const listTbody=$('swAssetList'); if(!listTbody) return;
  const q=($('swSearchBox')?.value||'').toLowerCase();
  const filtered=q?items.filter(a=>Object.values(a).some(v=>String(v).toLowerCase().includes(q))):items;
  if(!filtered.length) listTbody.innerHTML='<tr><td colspan="6" style="text-align:center;color:var(--muted)">해당 조건의 장비가 없습니다</td></tr>';
  else{listTbody.innerHTML='';filtered.forEach(a=>{const tr=document.createElement('tr');[a.manage_no,a.asset_name,a.ip,a.hostname,a.sw_name,a.sw_version].forEach(v=>{const td=document.createElement('td');td.textContent=v||'';tr.appendChild(td);});listTbody.appendChild(tr);});}
}

// ════════════════════════════════════════
//  ★ 랙 실장도 42U (드래그 배치) - 버그 수정
// ════════════════════════════════════════
function getAssetTypeColor(type){
  const t=(type||'').toLowerCase();
  if(t.includes('서버')) return 'typeColor-server';
  if(t.includes('스위치')||t.includes('방화벽')||t.includes('l3')) return 'typeColor-network';
  if(t.includes('보안')) return 'typeColor-security';
  if(t.includes('db')||t.includes('데이터')) return 'typeColor-db';
  return 'typeColor-etc';
}
function _gf(a,names){ for(const n of names){const v=(a[n]||'').toString().trim();if(v) return v;} return ''; }

const RACK_TOTAL_U = 42;

function renderRackLayout(){
  const container=$('rackContainer'),filterLoc=$('rackFilterLoc');
  if(!container) return;

  const locSet=new Set(), grouped={};
  STATE.assets.forEach(a=>{
    const loc=_gf(a,['물리적장소','phy_loc']);
    const rackPos=_gf(a,['랙위치','rack_loc']);
    if(!loc&&!rackPos) return;
    if(loc) locSet.add(loc);
    const locKey=loc||'미분류', posKey=rackPos||'미지정';
    const gk=`${locKey}||${posKey}`;
    if(!grouped[gk]) grouped[gk]=[];
    const rackNo=parseInt((_gf(a,['렉 번호','rack_no'])||'0').replace(/\D/g,''))||0;
    const uRaw = _gf(a,['장비크기(U)','장비크기','size','장비크기(U) ']) || '1';
    const uSize = parseInt(String(uRaw).replace(/\D/g,'')) || 1;
    grouped[gk].push({asset:a, rackNo, uSize});
  });

  if(filterLoc){
    const pv=filterLoc.value;
    filterLoc.innerHTML='<option value="">전체 장소</option>';
    Array.from(locSet).sort().forEach(l=>{const o=document.createElement('option');o.value=l;o.textContent=l;filterLoc.appendChild(o);});
    filterLoc.value=pv;
  }

  const selectedLoc=filterLoc?filterLoc.value:'';
  container.innerHTML='';
  const allLocs=[...new Set(Object.keys(grouped).map(k=>k.split('||')[0]))].sort();
  let shownCount=0;

  allLocs.forEach(loc=>{
    if(selectedLoc&&loc!==selectedLoc) return;
    const rackKeys=Object.keys(grouped).filter(k=>k.startsWith(loc+'||')).sort((a,b)=>a.split('||')[1].localeCompare(b.split('||')[1]));
    if(!rackKeys.length) return;

    const locHeader=document.createElement('div');
    locHeader.className='rackLocHeader';
    locHeader.innerHTML=`<i class="fa fa-building"></i> ${escapeHtml(loc)}`;
    container.appendChild(locHeader);

    const rackRow=document.createElement('div');
    rackRow.className='rackRow';

    rackKeys.forEach(gk=>{
      shownCount++;
      const posName=gk.split('||')[1];
      const entries=grouped[gk];

      const occupancy={};
      entries.forEach(e=>{
        if(e.rackNo>0){
          for(let u=e.rackNo;u<e.rackNo+e.uSize&&u<=RACK_TOTAL_U;u++) occupancy[u]=e;
        }
      });

      const rackDiv=document.createElement('div');
      rackDiv.className='rackUnit rack42';

      const header=document.createElement('div');
      header.className='rackHeader';
      const usedU=entries.reduce((s,e)=>s+e.uSize,0);
      header.innerHTML=`<i class="fa fa-server"></i> <span>${escapeHtml(posName)}</span>
        <span class="rackCount">${usedU}/${RACK_TOTAL_U}U</span>`;
      rackDiv.appendChild(header);

      const slotsDiv=document.createElement('div');
      slotsDiv.className='rack42Slots';

      for(let u=RACK_TOTAL_U;u>=1;u--){
        const occ=occupancy[u];
        if(occ){
          const slot=document.createElement('div');
          slot.className='rack42Slot rack42Filled';
          const tc=getAssetTypeColor(occ.asset['자산유형']||occ.asset.asset_type||'');
          slot.classList.add(tc);

          const isStart=(occ.rackNo===u);
          if(isStart){
            slot.draggable=true;
            slot.dataset.assetId=occ.asset.id;
            slot.dataset.rackGk=gk;
            slot.dataset.origU=String(u);
            const name=occ.asset['자산명']||occ.asset.asset_name||'(이름없음)';
            const ip=occ.asset['IP']||occ.asset.ip_addr||'';
            slot.innerHTML=`
              <span class="rack42No">${u}${occ.uSize>1?` (${occ.uSize}U)`:''}</span>
              <span class="rack42Name">${escapeHtml(name)}</span>
              <span class="rack42Info">${escapeHtml(ip)}</span>
              <span class="rack42Size">${occ.uSize}U</span>`;
            slot.title=`${name} | ${ip} | ${occ.uSize}U | 관리번호: ${occ.asset['관리번호']||''}`;

            slot.addEventListener('dragstart',e=>{
              e.dataTransfer.setData('text/plain',JSON.stringify({assetId:occ.asset.id,uSize:occ.uSize,gk}));
              slot.classList.add('rack42Dragging');
            });
            slot.addEventListener('dragend',()=>slot.classList.remove('rack42Dragging'));
          }else{
            slot.classList.add('rack42Cont');
            slot.innerHTML=`<span class="rack42No">${u}</span><span class="rack42Info" style="opacity:.7">↟</span>`;
          }
          slotsDiv.appendChild(slot);
        } else {
          // ★ 버그 수정: 중복 else if 제거
          const slot=document.createElement('div');
          slot.className='rack42Slot rack42Empty';
          slot.dataset.uPos=String(u);
          slot.dataset.rackGk=gk;
          slot.innerHTML=`<span class="rack42No">${u}</span>`;

          slot.addEventListener('dragover',e=>{e.preventDefault();slot.classList.add('rack42DropTarget');});
          slot.addEventListener('dragleave',()=>slot.classList.remove('rack42DropTarget'));
          slot.addEventListener('drop',async e=>{
            e.preventDefault();slot.classList.remove('rack42DropTarget');
            try{
              const d=JSON.parse(e.dataTransfer.getData('text/plain'));
              if(d.gk!==gk){showToast('같은 랙 내에서만 이동 가능','error');return;}
              const newPos=parseInt(slot.dataset.uPos);
              for(let cu=newPos;cu<newPos+d.uSize;cu++){
                if(occupancy[cu]&&occupancy[cu].asset.id!==d.assetId){showToast(`U${cu} 위치에 다른 장비가 있습니다`,'error');return;}
              }
              if(newPos+d.uSize-1>RACK_TOTAL_U){showToast('랙 범위를 초과합니다','error');return;}
              await api(`/api/assets/${encodeURIComponent(d.assetId)}`,{method:'PATCH',body:{field:'렉 번호',value:String(newPos)}});
              showToast(`U${newPos} 위치로 이동됨`,'success');
              await reloadBootstrap();
              renderRackLayout();
            }catch(err){showToast(`이동 실패: ${err.message}`,'error');}
          });
          slotsDiv.appendChild(slot);
        }
      }

      rackDiv.appendChild(slotsDiv);
      rackRow.appendChild(rackDiv);
    });
    container.appendChild(rackRow);
  });

  if(!shownCount){
    container.innerHTML=`<div class="rackEmpty" style="width:100%;padding:60px;text-align:center">
      <i class="fa fa-server" style="font-size:36px;opacity:.3;display:block;margin-bottom:12px"></i>
      <p style="font-size:14px;font-weight:700;margin:0 0 6px">랙 정보가 없습니다</p>
      <p style="margin:0;font-size:12px">자산의 <b>물리적장소</b>, <b>랙위치</b>, <b>렉 번호</b>, <b>장비크기</b>를 입력하면 자동 렌더링됩니다.</p>
    </div>`;
  }
}

// ════════════════════════════════════════
//  대시보드 / 감사로그
// ════════════════════════════════════════
async function loadDashboard(){
  const c=$('dashboardContent'); if(!c) return;
  c.innerHTML='<div style="text-align:center;padding:40px;color:var(--muted)">로딩 중...</div>';
  try{
    const d=await api('/api/dashboard');
    let h=`<div class="dashRow">
      <div class="dashCard"><div class="dashIcon"><i class="fa fa-server"></i></div><div class="dashNum">${d.total}</div><div class="dashLabel">전체 자산</div></div>
      <div class="dashCard"><div class="dashIcon" style="color:#06b6d4"><i class="fa fa-cubes"></i></div><div class="dashNum">${d.sw_total}</div><div class="dashLabel">S/W 종류</div></div>
      <div class="dashCard"><div class="dashIcon" style="color:#f59e0b"><i class="fa fa-file-text"></i></div><div class="dashNum">${d.manual_total}</div><div class="dashLabel">등록 문서</div></div>
      <div class="dashCard"><div class="dashIcon" style="color:#10b981"><i class="fa fa-link"></i></div><div class="dashNum">${d.conn_total||0}</div><div class="dashLabel">장비 연결</div></div>
      <div class="dashCard"><div class="dashIcon" style="color:#8b5cf6"><i class="fa fa-building"></i></div><div class="dashNum">${Object.keys(d.loc_counts||{}).length}</div><div class="dashLabel">물리적 장소</div></div></div>`;
    const makeBar=(title,icon,counts,cls)=>{
      h+=`<div class="dashSection"><h4 class="cardTitle"><i class="fa ${icon}" style="margin-right:6px"></i>${title}</h4><div class="dashBarGroup">`;
      const mx=Math.max(...Object.values(counts||{}),1);
      for(const [k,v] of Object.entries(counts||{}).sort((a,b)=>b[1]-a[1])){
        h+=`<div class="dashBarItem"><span class="dashBarLabel">${escapeHtml(k)}</span><div class="dashBarTrack"><div class="dashBarFill ${cls}" style="width:${Math.round(v/mx*100)}%"></div></div><span class="dashBarVal">${v}</span></div>`;
      }
      h+=`</div></div>`;
    };
    makeBar('자산유형별','fa-pie-chart',d.type_counts,'');
    makeBar('망구분별','fa-shield',d.net_counts,'dashBarFillPurple');
    makeBar('장소별','fa-building',d.loc_counts,'dashBarFillGreen');
    if(d.status_counts&&Object.keys(d.status_counts).length>0)
      makeBar('유지보수 상태','fa-wrench',d.status_counts,'dashBarFillAmber');
    c.innerHTML=h;
  }catch(err){c.innerHTML=`<div style="text-align:center;padding:40px;color:var(--danger)">${escapeHtml(err.message)}</div>`;}
}

async function loadAuditLog(){
  const tbody=$('auditList'); if(!tbody) return;
  tbody.innerHTML='<tr><td colspan="6" style="text-align:center;color:var(--muted)">로딩 중...</td></tr>';
  try{
    const search=($('auditSearch')?.value||'').trim();
    const action=$('auditFilter')?.value||'';
    let url='/api/audit?limit=300';
    if(search) url+=`&search=${encodeURIComponent(search)}`;
    if(action) url+=`&action=${encodeURIComponent(action)}`;
    const data=await api(url);
    const items=data.items||[]; tbody.innerHTML='';
    if(!items.length){tbody.innerHTML='<tr><td colspan="6" style="text-align:center;color:var(--muted)">변경 이력이 없습니다</td></tr>';return;}
    const labels={CREATE:'생성',UPDATE:'수정',DELETE:'삭제',IMPORT:'엑셀',BACKUP:'백업',SW_ADD:'S/W',MANUAL_ADD:'매뉴얼',LOGIN:'로그인',LOGOUT:'로그아웃',CLONE:'복제',USER_ADD:'사용자',PW_CHANGE:'비번변경',LOGIN_FAIL:'로그인실패',CONNECT:'연결',DISCONNECT:'연결해제'};
    const colors={CREATE:'#10b981',UPDATE:'#3b82f6',DELETE:'#ef4444',IMPORT:'#f59e0b',BACKUP:'#8b5cf6',SW_ADD:'#06b6d4',MANUAL_ADD:'#14b8a6',LOGIN:'#22d3ee',LOGOUT:'#94a3b8',CLONE:'#f97316',USER_ADD:'#a78bfa',PW_CHANGE:'#f59e0b',LOGIN_FAIL:'#ef4444',CONNECT:'#10b981',DISCONNECT:'#f43f5e'};
    items.forEach((item,idx)=>{
      const tr=document.createElement('tr');
      const tdNo=document.createElement('td');tdNo.style.textAlign='center';tdNo.textContent=String(idx+1);tr.appendChild(tdNo);
      const tdTime=document.createElement('td');tdTime.textContent=item.created_at||'';tdTime.style.fontSize='11px';tr.appendChild(tdTime);
      const tdUser=document.createElement('td');tdUser.textContent=item.user||'-';tdUser.style.fontSize='12px';tr.appendChild(tdUser);
      const tdAction=document.createElement('td');
      const badge=document.createElement('span');badge.textContent=labels[item.action]||item.action;
      badge.style.cssText=`padding:3px 8px;border-radius:6px;font-size:11px;font-weight:800;background:${colors[item.action]||'#6b7280'}22;color:${colors[item.action]||'#6b7280'}`;
      tdAction.appendChild(badge);tr.appendChild(tdAction);
      const tdAsset=document.createElement('td');tdAsset.textContent=item.asset_id||'-';tdAsset.style.fontSize='12px';tr.appendChild(tdAsset);
      const tdDetail=document.createElement('td');tdDetail.textContent=(item.detail||'').slice(0,120);tdDetail.style.cssText='font-size:11px;color:var(--muted);max-width:400px;overflow:hidden;text-overflow:ellipsis';tr.appendChild(tdDetail);
      tbody.appendChild(tr);
    });
  }catch(err){tbody.innerHTML=`<tr><td colspan="6" style="color:var(--danger)">${escapeHtml(err.message)}</td></tr>`;}
}

// ════════════════════════════════════════
//  엑셀 내보내기
// ════════════════════════════════════════
async function exportFullXls(){
  setLoading(true);
  try{
    const data=await api('/api/export/full');
    const assets=data.assets||[], fields=data.fields||FIELDS;
    const headers=[...fields,'S/W 목록'];
    const rows=assets.map(a=>{const r=fields.map(f=>a[f]||'');r.push(a._sw_list||'');return r;});
    const ws=XLSX.utils.aoa_to_sheet([headers,...rows]);
    ws['!cols']=headers.map((h,i)=>{let m=h.length;rows.forEach(r=>{const l=String(r[i]||'').length;if(l>m)m=l;});return{wch:Math.min(m+2,50)};});
    const wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,ws,'자산목록');
    XLSX.writeFile(wb,'자산목록_전체.xlsx'); showToast('엑셀 내보내기 완료','success');
  }catch(err){showToast(`실패: ${err.message}`,'error');}finally{setLoading(false)}
}
function exportXls(){
  try{const wb=XLSX.utils.table_to_book($('mainTable'));XLSX.writeFile(wb,'자산목록.xlsx');showToast('엑셀 다운로드 완료','success');}
  catch(err){showToast(`실패: ${err.message}`,'error');}
}

function printPage(){ window.print(); }

// ════════════════════════════════════════
//  Actions
// ════════════════════════════════════════
async function saveAsset(){
  const editingId=$('mEditingId').value.trim();
  const payload={
    '자산명':$('mName').value.trim(), 'IP':$('mIP').value.trim(),
    '자산유형':$('mType').value, '망구분':$('mNet').value,
    '관리번호':$('mNo').value.trim(), 'Hostname':$('mHost').value.trim(),
    '물리적장소':$('mLoc').value.trim(),
    'is_dummy':$('mType').value==='임의장비',
  };
  if($('mRackLoc')) payload['랙위치']=$('mRackLoc').value.trim();
  if($('mRackNo')) payload['렉 번호']=$('mRackNo').value.trim();
  if($('mUSize')) payload['장비크기']=$('mUSize').value.trim()||'1';
  if($('mCategory')) payload['분류']=$('mCategory').value.trim();
  if($('mHwType')) payload['유형']=$('mHwType').value.trim();
  if($('mMfr')) payload['제조사']=$('mMfr').value.trim();
  if($('mModel')) payload['모델명']=$('mModel').value.trim();
  if($('mSerial')) payload['시리얼']=$('mSerial').value.trim();
  if($('mOS')) payload['OS']=$('mOS').value.trim();
  if($('mCPU')) payload['CPU 코어']=$('mCPU').value.trim();
  if($('mMemory')) payload['메모리']=$('mMemory').value.trim();
  if($('mDisk')) payload['디스크']=$('mDisk').value.trim();
  if($('mManager1')) payload['담당자1']=$('mManager1').value.trim();
  if($('mManager2')) payload['담당자2']=$('mManager2').value.trim();
  if($('mMaintCo')) payload['유지보수업체']=$('mMaintCo').value.trim();
  if($('mMaintEng')) payload['담당엔지니어']=$('mMaintEng').value.trim();
  if($('mOwner')) payload['자산소유']=$('mOwner').value.trim();
  if($('mMaint')) payload['유지보수']=$('mMaint').value.trim();
  if($('mProject')) payload['도입사업']=$('mProject').value.trim();
  if($('mIntroDate')) payload['도입년월']=$('mIntroDate').value.trim();
  if($('mPrice')) payload['도입금액']=$('mPrice').value.trim();
  if($('mNote')) payload['비고']=$('mNote').value.trim();

  setLoading(true);
  try{
    if(editingId){
      const pairs=Object.entries(payload).filter(([k])=>k!=='is_dummy');
      for(const [field,value] of pairs)
        await api(`/api/assets/${encodeURIComponent(editingId)}`,{method:'PATCH',body:{field,value}});
      showToast('수정 완료','success');
    }else{
      await api('/api/assets',{method:'POST',body:payload});
      showToast('등록 완료','success');
    }
    await reloadBootstrap(); closeModal($('assetModal')); await filterAndRender();
    if(STATE.network) STATE.network.setData({nodes:new vis.DataSet(STATE.visNodes),edges:new vis.DataSet(STATE.visEdges)});
  }catch(err){showToast(`실패: ${err.message}`,'error');}
  finally{setLoading(false)}
}

async function deleteAsset(id){
  if(!confirm('이 자산을 삭제하시겠습니까?\n연결된 S/W, 매뉴얼, 연결 정보도 함께 삭제됩니다.')) return;
  setLoading(true);
  try{
    await api(`/api/assets/${encodeURIComponent(id)}`,{method:'DELETE'}); showToast('삭제됨','success');
    await reloadBootstrap(); await filterAndRender();
    if(STATE.network) STATE.network.setData({nodes:new vis.DataSet(STATE.visNodes),edges:new vis.DataSet(STATE.visEdges)});
  }catch(err){showToast(`실패: ${err.message}`,'error');}
  finally{setLoading(false)}
}

async function saveConn(){
  const src=$('connSrc').value,tgt=$('connTgt').value,label=$('connLabel').value.trim()||'연결됨';
  if(src===tgt){showToast('동일 장비 연결 불가','error');return;}
  setLoading(true);
  try{
    await api('/api/connections',{method:'POST',body:{source:src,target:tgt,label}});
    showToast('연결 생성됨','success'); await reloadBootstrap();
    if(STATE.network) STATE.network.setData({nodes:new vis.DataSet(STATE.visNodes),edges:new vis.DataSet(STATE.visEdges)});
    closeModal($('connModal'));
  }catch(err){showToast(`실패: ${err.message}`,'error');}
  finally{setLoading(false)}
}

async function editTitle(){
  const t=prompt('제목 수정',$('pageTitle').textContent); if(!t) return;
  setLoading(true);
  try{await api('/api/title',{method:'PATCH',body:{title:t}});$('pageTitle').textContent=t;showToast('제목 저장됨','success');}
  catch(err){showToast(`실패: ${err.message}`,'error');}finally{setLoading(false)}
}

function setEmptyState(on){const el=$('emptyState');if(el) el.hidden=!on;}
function setTableVisible(on){const t=$('mainTable');if(t) t.style.display=on?'':'none';}

function importXls(file){
  if(!file) return; setLoading(true);
  const reader=new FileReader();
  reader.onload=async e=>{
    try{
      const wb=XLSX.read(e.target.result,{type:'array'});
      const json=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{raw:false,dateNF:'yyyy-mm-dd'});
      if(!json?.length){showToast('데이터 없음','error');return;}
      const v=await api('/api/import/excel/validate',{method:'POST',body:json});
      if(v.invalid_count>0){
        const rows=[['row','field','error'],...(v.errors||[]).map(e=>[e.row,e.field,e.error])];
        const csv=rows.map(r=>r.map(x=>`"${String(x??'').replaceAll('"','""')}"`).join(',')).join('\n');
        const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
        const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='excel_validation_report.csv';
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        if(!confirm(`검증 실패 ${v.invalid_count}건이 있습니다.\n정상 ${v.valid_count}건만 등록할까요?\n(오류 리포트가 다운로드됩니다)`)){
          showToast('업로드 취소됨'); return;
        }
      }
      const r=await api('/api/import/excel',{method:'POST',body:json});
      showToast(`업로드 완료 (등록 ${r.inserted}건 / 스킵 ${r.skipped}건)`,'success');await reloadBootstrap();await filterAndRender();
    }catch(err){showToast(`실패: ${err.message}`,'error');}
    finally{setLoading(false);$('xlsInput').value='';}
  };
  reader.onerror=()=>{showToast('파일 읽기 실패','error');setLoading(false);};
  reader.readAsArrayBuffer(file);
}

async function makeBackup(){
  setLoading(true);
  try{const r=await api('/api/backup',{method:'POST'});showToast(`백업: ${r.file}`,'success');}
  catch(err){showToast(`실패: ${err.message}`,'error');}finally{setLoading(false)}
}

// ──── 사용자 관리 ────
async function openUserModal(){
  openModal($('userModal'));
  await loadUserList();
}
async function loadUserList(){
  const tbody=$('userList'); if(!tbody) return;
  tbody.innerHTML='<tr><td colspan="7" style="text-align:center;color:var(--muted)">로딩 중...</td></tr>';
  try{
    const data=await api('/api/users');
    const items=data.items||[]; tbody.innerHTML='';
    items.forEach(u=>{
      const tr=document.createElement('tr');
      [u.username,u.display_name].forEach(v=>{const td=document.createElement('td');td.textContent=v||'';tr.appendChild(td);});
      const tdRole=document.createElement('td');
      const roleLabels={admin:'관리자',user:'사용자',viewer:'뷰어'};
      tdRole.textContent=roleLabels[u.role]||u.role; tr.appendChild(tdRole);
      const tdStatus=document.createElement('td');
      const active=u.is_active!==0;
      const badge=document.createElement('span');
      badge.className=`statusBadge ${active?'statusActive':'statusInactive'}`;
      badge.textContent=active?'활성':'비활성';
      tdStatus.appendChild(badge); tr.appendChild(tdStatus);
      const tdLast=document.createElement('td');tdLast.textContent=u.last_login||'-';tdLast.style.fontSize='11px';tr.appendChild(tdLast);
      const tdCreated=document.createElement('td');tdCreated.textContent=(u.created_at||'').slice(0,10);tdCreated.style.fontSize='11px';tr.appendChild(tdCreated);
      const tdAct=document.createElement('td');
      const actWrap=document.createElement('div');actWrap.style.cssText='display:flex;gap:4px';
      const btnToggle=document.createElement('button');btnToggle.className='iconMini';
      btnToggle.innerHTML=active?'<i class="fa fa-ban"></i>':'<i class="fa fa-check"></i>';
      btnToggle.title=active?'비활성화':'활성화';
      btnToggle.addEventListener('click',async()=>{
        try{await api(`/api/users/${u.id}`,{method:'PATCH',body:{is_active:!active}});showToast('변경됨','success');await loadUserList();}catch(e){showToast(e.message,'error');}
      });
      actWrap.appendChild(btnToggle);
      const btnPw=document.createElement('button');btnPw.className='iconMini';btnPw.innerHTML='<i class="fa fa-key"></i>';btnPw.title='비밀번호 변경';
      btnPw.addEventListener('click',async()=>{
        const pw=prompt(`${u.username} 새 비밀번호 (4자 이상):`);
        if(!pw) return;
        try{await api(`/api/users/${u.id}/password`,{method:'PATCH',body:{password:pw}});showToast('비밀번호 변경됨','success');}catch(e){showToast(e.message,'error');}
      });
      actWrap.appendChild(btnPw);
      const btnDel=document.createElement('button');btnDel.className='iconMini';btnDel.innerHTML='<i class="fa fa-trash"></i>';
      btnDel.addEventListener('click',async()=>{
        if(!confirm(`${u.username} 삭제?`)) return;
        try{await api(`/api/users/${u.id}`,{method:'DELETE'});showToast('삭제됨','success');await loadUserList();}catch(e){showToast(e.message,'error');}
      });
      actWrap.appendChild(btnDel);
      tdAct.appendChild(actWrap);tr.appendChild(tdAct);
      tbody.appendChild(tr);
    });
  }catch(err){tbody.innerHTML=`<tr><td colspan="7" style="color:var(--danger)">${escapeHtml(err.message)}</td></tr>`;}
}
async function addUser(){
  const u=$('newUsername').value.trim(),p=$('newPassword').value,d=$('newDisplayName').value.trim(),r=$('newRole').value;
  if(!u||!p){showToast('아이디/비밀번호 필수','error');return;}
  if(p.length<4){showToast('비밀번호는 4자 이상','error');return;}
  try{
    await api('/api/users',{method:'POST',body:{username:u,password:p,display_name:d||u,role:r}});
    showToast('사용자 추가됨','success');$('newUsername').value='';$('newPassword').value='';$('newDisplayName').value='';
    await loadUserList();
  }catch(err){showToast(err.message,'error');}
}

// ──── 사용자 매뉴얼 ────
function openHelpModal(){
  $('helpContent').innerHTML=`
<h2>1. 시스템 개요</h2>
<p>본 자산관리시스템은 조직의 IT 자산(서버, 네트워크 장비, 보안장비 등)을 체계적으로 등록하고 관리하기 위한 웹 기반 도구입니다.</p>
<ul>
  <li><b>자산 목록</b> — 등록된 전체 자산을 테이블 형식으로 조회/관리</li>
  <li><b>네트워크 맵</b> — 장비 간 연결 관계를 시각적으로 표시</li>
  <li><b>S/W 구성도</b> — 자산별 설치 소프트웨어 현황 관리</li>
  <li><b>랙 실장도</b> — 물리적 랙에 장비 배치 상태를 42U 기준으로 표시</li>
  <li><b>대시보드</b> — 전체 자산 현황 통계</li>
  <li><b>변경 이력</b> — 모든 변경 작업의 감사 기록</li>
</ul>

<h2>2. 로그인 / 계정 관리</h2>
<p>초기 관리자 계정은 <code>admin / admin123</code> 입니다. 최초 로그인 후 반드시 비밀번호를 변경하세요.</p>
<h3>권한 구분</h3>
<ul>
  <li><b>관리자 (admin)</b> — 모든 기능 사용 가능, 사용자 계정 관리</li>
  <li><b>일반 사용자 (user)</b> — 자산 등록/수정/삭제, S/W 및 매뉴얼 관리</li>
  <li><b>뷰어 (viewer)</b> — 조회 전용 (읽기만 가능)</li>
</ul>

<h2>3. 자산 관리</h2>
<h3>상세보기</h3>
<p>테이블 좌측 <i class="fa fa-info-circle"></i> 버튼으로 자산의 모든 정보를 한눈에 볼 수 있습니다.</p>
<h3>수정</h3>
<p>셀을 <b>더블클릭</b>하면 해당 셀을 직접 수정할 수 있습니다. <kbd>Enter</kbd>로 저장됩니다.</p>
<h3>전체 필드 편집</h3>
<p><i class="fa fa-pencil"></i> 버튼 클릭 시 모든 필드를 편집할 수 있는 모달이 열립니다.</p>
<h3>검색</h3>
<p>상단 검색창에 키워드를 입력하면 실시간으로 필터링됩니다. 컬럼 헤더 클릭으로 정렬합니다.</p>

<h2>4. S/W 관리</h2>
<p><b>관리번호</b> 셀 클릭 → S/W 관리 모달에서 소프트웨어를 등록/삭제합니다.</p>

<h2>5. 매뉴얼/문서 관리</h2>
<p><b>자산명</b> 셀 클릭 → 문서 업로드/미리보기/다운로드를 합니다.</p>

<h2>6. 랙 실장도</h2>
<p>42U 기준 랙을 물리적 장소별로 표시합니다. 드래그로 장비 위치를 변경할 수 있습니다.</p>

<h2>7. 키보드 단축키</h2>
<ul>
  <li><kbd>Enter</kbd> — 검색 실행 / 셀 편집 저장</li>
  <li><kbd>Esc</kbd> — 모달 닫기</li>
  <li>더블클릭 — 셀 인라인 편집</li>
</ul>
`;
  openModal($('helpModal'));
}

// ──── Bootstrap / 연결 맵 ────
function buildConnMap(){
  STATE.connMap={};
  const nodeMap={};
  STATE.visNodes.forEach(n=>nodeMap[n.id]=n.label||n.id);
  STATE.visEdges.forEach(e=>{
    const s=e.from||e.source, t=e.to||e.target;
    if(!STATE.connMap[s]) STATE.connMap[s]=[];
    if(!STATE.connMap[t]) STATE.connMap[t]=[];
    STATE.connMap[s].push({id:t,label:nodeMap[t]||t});
    STATE.connMap[t].push({id:s,label:nodeMap[s]||s});
  });
}

async function reloadBootstrap(){
  const data=await api('/api/bootstrap');
  STATE.assets=data.assets||[]; STATE.visNodes=data.visNodes||[];
  STATE.visEdges=data.visEdges||[]; STATE.title=data.title||'';
  buildConnMap();
  refreshNetOptions();
  setEmptyState(!STATE.assets.length); setTableVisible(!!STATE.assets.length);
}

// ──── 컬럼 설정 ────
function applyHiddenColumns(hidden){
  STATE.settings.hiddenColumns=Array.isArray(hidden)?hidden:[];
  let style=$('colHideStyle');
  if(!style){style=document.createElement('style');style.id='colHideStyle';document.head.appendChild(style);}
  style.textContent=STATE.settings.hiddenColumns.map(f=>`th[data-field="${f.replaceAll('\\','\\\\').replaceAll('"','\\"')}"],td[data-field="${f.replaceAll('\\','\\\\').replaceAll('"','\\"')}"]{display:none !important;}`).join('\n');
}
async function loadColumnSetting(){try{return(await api('/api/settings/columns')).hidden||[];}catch{return[];}}
function refreshNetOptions(){
  const values=new Set();
  (STATE.assets||[]).forEach(a=>{
    const v=_gf(a,['망구분','network_type']);
    if(v) values.add(String(v).trim());
  });
  const list=Array.from(values).filter(Boolean).sort((a,b)=>a.localeCompare(b,'ko'));
  const apply=(sel, withAll)=>{
    if(!sel) return;
    const prev=sel.value;
    sel.innerHTML='';
    if(withAll){ const o=document.createElement('option');o.value='';o.textContent='전체 망';sel.appendChild(o); }
    else { const o=document.createElement('option');o.value='';o.textContent='선택';sel.appendChild(o); }
    list.forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v;sel.appendChild(o);});
    if(prev && list.includes(prev)) sel.value=prev;
  };
  apply($('filterNet'), true);
  apply($('mapFilterNet'), true);
  apply($('mNet'), false);
}
async function saveColumnSetting(hidden){await api('/api/settings/columns',{method:'PUT',body:{hidden}});}
function buildColumnsModal(){
  const grid=$('columnsGrid'); if(!grid) return; grid.innerHTML='';
  const hidden=new Set(STATE.settings.hiddenColumns||[]);
  FIELDS.forEach(f=>{
    const row=document.createElement('div');row.className='colItem';
    const cb=document.createElement('input');cb.type='checkbox';cb.checked=!hidden.has(f);cb.dataset.field=f;
    const label=document.createElement('div');label.textContent=f;
    row.appendChild(cb);row.appendChild(label);grid.appendChild(row);
  });
}
function collectHiddenFromColumnsModal(){
  const hidden=[];
  $('columnsGrid').querySelectorAll('input[type="checkbox"]').forEach(cb=>{if(!cb.checked) hidden.push(cb.dataset.field);});
  return hidden;
}

// ══════════════════════════════════════════
//  Init
// ══════════════════════════════════════════
async function init(){
  initTabs(); renderTableHead(); bindFilters(); bindInfiniteScroll();
  bindCellEditing(); bindTableActions(); bindCellClickManagement();

  $('btnNew')?.addEventListener('click',()=>openAssetModalById(''));
  $('btnColumns')?.addEventListener('click',()=>{buildColumnsModal();openModal($('columnsModal'));});
  $('btnConnect')?.addEventListener('click',openConnModal);
  $('btnDummy')?.addEventListener('click',()=>{resetAssetModal();$('assetModalTitle').textContent='임의 장비 등록';$('mType').value='임의장비';openModal($('assetModal'));});
  $('btnUsers')?.addEventListener('click',openUserModal);
  $('btnHelp')?.addEventListener('click',openHelpModal);

  $('overlay')?.addEventListener('click',()=>{
    ['assetModal','connModal','softwareModal','manualModal','columnsModal','userModal','helpModal','detailModal'].forEach(id=>closeModal($(id)));
  });
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'){
      ['helpModal','columnsModal','userModal','connModal','softwareModal','manualModal','assetModal','detailModal'].forEach(id=>{
        const m=$(id); if(m&&!m.hidden){closeModal(m);e.stopPropagation();}
      });
    }
  });

  $('assetModalClose')?.addEventListener('click',()=>closeModal($('assetModal')));
  $('btnCancelAsset')?.addEventListener('click',()=>closeModal($('assetModal')));
  $('btnSaveAsset')?.addEventListener('click',saveAsset);
  $('connModalClose')?.addEventListener('click',()=>closeModal($('connModal')));
  $('btnCancelConn')?.addEventListener('click',()=>closeModal($('connModal')));
  $('btnSaveConn')?.addEventListener('click',saveConn);
  $('softwareModalClose')?.addEventListener('click',()=>closeModal($('softwareModal')));
  $('btnSwAdd')?.addEventListener('click',addSoftware);
  $('manualModalClose')?.addEventListener('click',()=>closeModal($('manualModal')));
  $('btnManualPick')?.addEventListener('click',()=>$('manualFileInput').click());
  $('manualFileInput')?.addEventListener('change',e=>{const f=e.target.files?.[0];_pickedManualFile=f||null;$('manualFileName').value=f?f.name:'';});
  $('btnManualUpload')?.addEventListener('click',uploadManual);
  $('columnsModalClose')?.addEventListener('click',()=>closeModal($('columnsModal')));
  $('btnColumnsReset')?.addEventListener('click',()=>{STATE.settings.hiddenColumns=[];buildColumnsModal();});
  $('btnColumnsHideAll')?.addEventListener('click',()=>{$('columnsGrid').querySelectorAll('input[type="checkbox"]').forEach(cb=>cb.checked=false);});
  $('btnColumnsSave')?.addEventListener('click',async()=>{
    const h=collectHiddenFromColumnsModal();
    try{await saveColumnSetting(h);applyHiddenColumns(h);closeModal($('columnsModal'));showToast('저장됨','success');}catch(e){showToast(e.message,'error');}
  });
  $('userModalClose')?.addEventListener('click',()=>closeModal($('userModal')));
  $('helpModalClose')?.addEventListener('click',()=>closeModal($('helpModal')));
  $('detailModalClose')?.addEventListener('click',()=>closeModal($('detailModal')));
  $('btnAddUser')?.addEventListener('click',addUser);

  $('swFilterName')?.addEventListener('change',loadSoftwareInventory);
  $('swFilterVersion')?.addEventListener('change',loadSoftwareInventory);
  $('btnSwRefresh')?.addEventListener('click',loadSoftwareInventory);
  $('swSearchBox')?.addEventListener('keyup',e=>{if(e.key==='Enter') renderSwTable(_swData);});
  $('rackFilterLoc')?.addEventListener('change',renderRackLayout);
  $('btnRackRefresh')?.addEventListener('click',renderRackLayout);
  $('pageTitle')?.addEventListener('click',editTitle);
  $('auditSearch')?.addEventListener('keyup',e=>{if(e.key==='Enter') loadAuditLog();});
  $('auditFilter')?.addEventListener('change',loadAuditLog);
  $('btnAuditRefresh')?.addEventListener('click',loadAuditLog);

  $('btnExport')?.addEventListener('click',exportXls);
  $('btnExportFull')?.addEventListener('click',exportFullXls);
  $('btnImport')?.addEventListener('click',()=>$('xlsInput').click());
  $('xlsInput')?.addEventListener('change',e=>importXls(e.target.files[0]));
  $('btnBackup')?.addEventListener('click',makeBackup);
  $('btnNetExport')?.addEventListener('click',exportNetworkImage);
  $('btnPrint')?.addEventListener('click',printPage);
  $('btnLogout')?.addEventListener('click',async()=>{
    try{await fetch('/api/logout',{method:'POST'});}catch{}
    window.location.href='/login';
  });

  setLoading(true);
  try{
    await reloadBootstrap();
    $('pageTitle').textContent=STATE.title||$('pageTitle').textContent;
    const hidden=await loadColumnSetting();
    applyHiddenColumns(hidden); await filterAndRender();
  }catch(err){showToast(`초기 로딩 실패: ${err.message}`,'error');setLoading(false);}
}

document.addEventListener('DOMContentLoaded',()=>init());
document.getElementById('btnEmptyNew')?.addEventListener('click',()=>openAssetModalById(''));
document.getElementById('btnEmptyImport')?.addEventListener('click',()=>document.getElementById('xlsInput').click());

/* ───────────── Monitoring ───────────── */
const MONITOR_COLUMNS = [
  {key:"network_type", label:"망구분"},
  {key:"hw_type", label:"유형"},
  {key:"asset_type", label:"자산유형"},
];

let monitorAllTargets = [];
let monitorGroups = [];
let monitorColumns = JSON.parse(localStorage.getItem("monitor_columns") || "[]"); // extra columns
function getCsrf(){ const el=document.querySelector('meta[name="csrf-token"]'); return el?el.content:""; }

async function apiGet(url){
  const r = await fetch(url, {headers: {"X-CSRF-Token": getCsrf()}});
  if(!r.ok) throw new Error(await r.text());
  return await r.json();
}
async function apiPost(url, data){
  const r = await fetch(url, {method:"POST", headers: {"Content-Type":"application/json","X-CSRF-Token": getCsrf()}, body: JSON.stringify(data||{})});
  if(!r.ok) throw new Error(await r.text());
  return await r.json();
}

function showModal(id, show=true){
  const el=document.getElementById(id);
  if(!el) return;
  el.style.display = show ? "flex" : "none";
}

function renderMonitorColumnsModal(){
  const box=document.getElementById("monitorColumnsList");
  if(!box) return;
  box.innerHTML="";
  MONITOR_COLUMNS.forEach(c=>{
    const checked = monitorColumns.includes(c.key);
    const row=document.createElement("label");
    row.style.display="flex"; row.style.alignItems="center"; row.style.gap="6px";
    row.innerHTML = `<input type="checkbox" data-key="${c.key}" ${checked?"checked":""}/> ${c.label}`;
    box.appendChild(row);
  });
  box.querySelectorAll("input[type=checkbox]").forEach(cb=>{
    cb.addEventListener("change", ()=>{
      const key=cb.getAttribute("data-key");
      if(cb.checked){
        if(!monitorColumns.includes(key)) monitorColumns.push(key);
      }else{
        monitorColumns = monitorColumns.filter(x=>x!==key);
      }
      localStorage.setItem("monitor_columns", JSON.stringify(monitorColumns));
      renderMonitorTable();
    });
  });
}

function renderMonitorGroups(){
  const sel=document.getElementById("monitorGroupFilter");
  if(sel){
    const cur=sel.value;
    sel.innerHTML = `<option value="">전체 그룹</option>` + monitorGroups.map(g=>`<option value="${g.id}">${escapeHtml(g.name)}</option>`).join("");
    sel.value = cur;
  }
  const list=document.getElementById("monitorGroupList");
  if(list){
    list.innerHTML = monitorGroups.map(g=>`
      <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #eee;">
        <div><b>${escapeHtml(g.name)}</b> <span class="muted">(#${g.id})</span></div>
        <button class="btn" data-del="${g.id}">삭제</button>
      </div>
    `).join("");
    list.querySelectorAll("button[data-del]").forEach(btn=>{
      btn.addEventListener("click", async ()=>{
        const gid=btn.getAttribute("data-del");
        if(!confirm("그룹을 삭제할까요? (대상 장비는 그룹 해제됩니다)")) return;
        await fetch(`/api/monitor/groups/${gid}`, {method:"DELETE", headers: {"X-CSRF-Token": getCsrf()}});
        await loadMonitorGroups();
      });
    });
  }
}

function escapeHtml(s){ return (s??"").toString().replace(/[&<>"']/g, m=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[m])); }

function renderMonitorTable(){
  const tbody=document.querySelector("#monitorTable tbody");
  if(!tbody) return;

  const groupId=document.getElementById("monitorGroupFilter")?.value || "";
  const onlyEnabled=document.getElementById("monitorOnlyEnabled")?.checked ?? true;

  let rows = monitorAllTargets.slice();
  if(groupId){
    rows = rows.filter(r=>String(r.group_id||"")===String(groupId));
  }
  if(onlyEnabled){
    rows = rows.filter(r=>Number(r.is_enabled||0)===1);
  }

  // build columns
  const thead=document.querySelector("#monitorTable thead tr");
  if(thead){
    let extraHeaders = monitorColumns.map(k=>{
      const label = (MONITOR_COLUMNS.find(x=>x.key===k)?.label) || k;
      return `<th>${escapeHtml(label)}</th>`;
    }).join("");
    thead.innerHTML = `
      <th style="width:70px;">ON/OFF</th>
      <th>자산명</th>
      <th style="width:140px;">IP</th>
      ${extraHeaders}
      <th style="width:90px;">상태</th>
      <th style="width:90px;">실패수</th>
      <th style="width:170px;">마지막 체크</th>
    `;
  }

  tbody.innerHTML = rows.map(r=>{
    const enabled = Number(r.is_enabled||0)===1;
    const st = (r.last_status||"");
    const stHtml = st==="DOWN" ? `<span class="statusDown">FAIL</span>` : (st==="UP" ? `<span class="statusUp">OK</span>` : `<span class="muted">-</span>`);
    const extraTds = monitorColumns.map(k=>`<td>${escapeHtml(r[k]||"")}</td>`).join("");
    return `
      <tr data-asset="${escapeHtml(r.asset_id)}" data-ip="${escapeHtml(r.ip||"")}">
        <td><label style="display:flex;justify-content:center"><input type="checkbox" class="monToggle" ${enabled?"checked":""}></label></td>
        <td>${escapeHtml(r.asset_name||"")}</td>
        <td>${escapeHtml(r.ip||"")}</td>
        ${extraTds}
        <td>${stHtml}</td>
        <td>${escapeHtml(String(r.fail_count||0))}</td>
        <td>${escapeHtml(r.last_checked_at||"")}</td>
      </tr>
    `;
  }).join("");

  tbody.querySelectorAll(".monToggle").forEach(cb=>{
    cb.addEventListener("change", async (e)=>{
      const tr=e.target.closest("tr");
      const asset_id=tr.getAttribute("data-asset");
      const ip=tr.getAttribute("data-ip");
      const asset_name=tr.children[1].innerText;
      const group_id = document.getElementById("monitorGroupFilter")?.value || null;
      await apiPost("/api/monitor/targets/upsert", {
        asset_id, asset_name, ip,
        is_enabled: e.target.checked ? 1 : 0,
        group_id: group_id ? Number(group_id) : null,
        extra_fields: monitorColumns
      });
      await loadMonitorTargets();
    });
  });
}

async function loadMonitorGroups(){
  monitorGroups = await apiGet("/api/monitor/groups");
  renderMonitorGroups();
}
async function loadMonitorTargets(){
  monitorAllTargets = await apiGet("/api/monitor/targets");
  // fill group filter options on first load
  renderMonitorTable();
}
async function pollMonitorStatus(){
  try{
    const groupId=document.getElementById("monitorGroupFilter")?.value || "";
    const onlyEnabled=document.getElementById("monitorOnlyEnabled")?.checked ?? true;
    const url = `/api/monitor/status?only_enabled=${onlyEnabled?1:0}` + (groupId?`&group_id=${encodeURIComponent(groupId)}`:"");
    const st = await apiGet(url);
    const map=new Map(st.map(x=>[`${x.asset_id}::${x.ip}`, x]));
    // merge into monitorAllTargets
    monitorAllTargets = monitorAllTargets.map(r=>{
      const k=`${r.asset_id}::${r.ip}`;
      const u=map.get(k);
      return u ? {...r, ...u} : r;
    });
    renderMonitorTable();
  }catch(e){
    // ignore
  }finally{
    setTimeout(pollMonitorStatus, 10000);
  }
}

async function loadMonitorSettings(){
  const s = await apiGet("/api/settings/monitor");
  document.getElementById("monitorInterval").value = s.interval_sec;
  document.getElementById("monitorFailThreshold").value = s.fail_threshold;
  document.getElementById("monitorNotifyMode").value = s.notify_mode;
  document.getElementById("monitorNotifyAccount").value = s.notify_account;
  document.getElementById("monitorNotifyRecovery").checked = Number(s.notify_recovery)===1;
  document.getElementById("rowNotifyAccount").style.display = (s.notify_mode==="account") ? "flex" : "none";
}

function hookMonitorUI(){
  document.getElementById("btnMonitorColumns")?.addEventListener("click", ()=>{ renderMonitorColumnsModal(); showModal("modalMonitorColumns", true); });
  document.getElementById("btnMonitorColumnsClose")?.addEventListener("click", ()=> showModal("modalMonitorColumns", false));

  document.getElementById("btnMonitorGroups")?.addEventListener("click", async ()=>{
    await loadMonitorGroups();
    showModal("modalMonitorGroups", true);
  });
  document.getElementById("btnMonitorGroupsClose")?.addEventListener("click", ()=> showModal("modalMonitorGroups", false));
  document.getElementById("btnCreateMonitorGroup")?.addEventListener("click", async ()=>{
    const name = (document.getElementById("newMonitorGroupName").value||"").trim();
    if(!name) return alert("그룹명을 입력하세요.");
    await apiPost("/api/monitor/groups", {name});
    document.getElementById("newMonitorGroupName").value="";
    await loadMonitorGroups();
  });

  document.getElementById("btnMonitorSettings")?.addEventListener("click", async ()=>{
    await loadMonitorSettings();
    showModal("modalMonitorSettings", true);
  });
  document.getElementById("btnMonitorSettingsClose")?.addEventListener("click", ()=> showModal("modalMonitorSettings", false));
  document.getElementById("monitorNotifyMode")?.addEventListener("change", (e)=>{
    document.getElementById("rowNotifyAccount").style.display = (e.target.value==="account") ? "flex" : "none";
  });
  document.getElementById("btnSaveMonitorSettings")?.addEventListener("click", async ()=>{
    const payload = {
      interval_sec: Number(document.getElementById("monitorInterval").value||10),
      fail_threshold: Number(document.getElementById("monitorFailThreshold").value||3),
      notify_mode: document.getElementById("monitorNotifyMode").value,
      notify_account: document.getElementById("monitorNotifyAccount").value,
      notify_recovery: document.getElementById("monitorNotifyRecovery").checked ? 1 : 0,
    };
    await apiPost("/api/settings/monitor", payload);
    showModal("modalMonitorSettings", false);
    alert("저장했습니다.");
  });

  document.getElementById("monitorGroupFilter")?.addEventListener("change", ()=> renderMonitorTable());
  document.getElementById("monitorOnlyEnabled")?.addEventListener("change", ()=> renderMonitorTable());
}

document.addEventListener("DOMContentLoaded", async ()=>{
  // 탭 클릭 시 monitor 로드
  hookMonitorUI();
  // lazy load when monitor tab clicked
  document.querySelectorAll(".tab").forEach(btn=>{
    btn.addEventListener("click", async ()=>{
      if(btn.getAttribute("data-tab")==="monitor"){
        await loadMonitorGroups();
        await loadMonitorTargets();
        pollMonitorStatus();
      }
    });
  });
});

