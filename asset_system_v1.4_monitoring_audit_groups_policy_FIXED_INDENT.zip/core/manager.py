import os
import secrets
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from core.db import get_conn
from core.validator import SecurityValidator


class SecurityAssetManager:
    def __init__(self, db_path: str):
        self.db_path = db_path

        self.fields = [
            "관리번호","분류","망구분","유형","자산유형","자산명","제조사","모델명","Hostname","IP",
            "렉위치","렉 번호","장비번호","수량","물리적장소","담당자1","담당자2","유지보수업체",
            "담당엔지니어","자산소유","유지보수","장비크기","시리얼","OS","CPU 코어","메모리",
            "디스크","도입사업","도입년월","도입금액","비고"
        ]

        self.col_map = {
            "관리번호":"manage_no",
            "분류":"category",
            "망구분":"network_type",
            "유형":"hw_type",
            "자산유형":"asset_type",
            "자산명":"asset_name",
            "제조사":"manufacturer",
            "모델명":"model_name",
            "Hostname":"hostname",
            "IP":"ip_addr",
            "렉위치":"rack_loc",
            "렉 번호":"rack_no",
            "장비번호":"equip_no",
            "수량":"quantity",
            "물리적장소":"phy_loc",
            "담당자1":"manager1",
            "담당자2":"manager2",
            "유지보수업체":"maint_company",
            "담당엔지니어":"maint_eng",
            "자산소유":"owner",
            "유지보수":"maint_status",
            "장비크기":"size",
            "시리얼":"serial",
            "OS":"os",
            "CPU 코어":"cpu",
            "메모리":"memory",
            "디스크":"disk",
            "도입사업":"project_name",
            "도입년월":"intro_date",
            "도입금액":"price",
            "비고":"note",
        }
        self.allowed_columns = set(self.col_map.values()) | {"id","label","group_name","no","status"}

        self.design = {
            "방화벽": {"color": "#ef4444", "code": "\uf132"},
            "스위치": {"color": "#f59e0b", "code": "\uf0e8"},
            "L3스위치": {"color": "#f97316", "code": "\uf0e8"},
            "서버": {"color": "#3b82f6", "code": "\uf233"},
            "DB": {"color": "#10b981", "code": "\uf1c0"},
            "보안장비": {"color": "#8b5cf6", "code": "\uf023"},
            "스토리지": {"color": "#06b6d4", "code": "\uf0a0"},
            "라우터": {"color": "#ec4899", "code": "\uf0ac"},
            "임의장비": {"color": "#94a3b8", "code": "\uf2db"},
            "Unknown": {"color": "#64748b", "code": "\uf128"},
        }

    # ---------- Settings ----------
    def get_title(self) -> str:
        conn = get_conn(self.db_path)
        try:
            row = conn.execute("SELECT value FROM settings WHERE key='dashboard_title'").fetchone()
            return row["value"] if row else "전산자산 관리 시스템"
        finally:
            conn.close()

    def update_title(self, title: str) -> None:
        title = SecurityValidator.sanitize(title, 100)
        conn = get_conn(self.db_path)
        try:
            conn.execute("UPDATE settings SET value=? WHERE key='dashboard_title'", (title,))
            conn.commit()
        finally:
            conn.close()

    # ---------- Query ----------
    def get_all_assets(self) -> List[Dict[str, Any]]:
        conn = get_conn(self.db_path)
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM assets WHERE status='active' ORDER BY created_at ASC")
            rows = cur.fetchall()

            assets: List[Dict[str, Any]] = []
            for r in rows:
                a = dict(r)
                for k_kor, k_eng in self.col_map.items():
                    a[k_kor] = a.get(k_eng, "") or ""

                sw = conn.execute(
                    "SELECT id, sw_type as type, sw_name as name, sw_version as version FROM software WHERE asset_id=?",
                    (a["id"],),
                ).fetchall()
                a["software"] = [dict(x) for x in sw]

                manuals = conn.execute(
                    "SELECT id, doc_name as name, file_path as file FROM manuals WHERE asset_id=?",
                    (a["id"],),
                ).fetchall()
                a["manuals"] = [dict(x) for x in manuals]

                assets.append(a)
            return assets
        finally:
            conn.close()

    def get_all_connections(self) -> List[Dict[str, Any]]:
        conn = get_conn(self.db_path)
        try:
            rows = conn.execute(
                "SELECT source_id as source, target_id as target, description as label FROM connections"
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def build_vis_nodes(self, assets: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        nodes: List[Dict[str, Any]] = []
        for a in assets:
            grp = a.get("group_name") or a.get("asset_type") or "Unknown"
            style = self.design.get(grp, self.design["Unknown"])
            label = a.get("label") or a.get("asset_name") or a.get("hostname") or a.get("ip_addr") or a["id"]
            zone = a.get("network_type") or a.get("망구분") or "기타"

            nodes.append(
                {
                    "id": a["id"],
                    "label": SecurityValidator.sanitize(label, 80),
                    "title": f"<b>{SecurityValidator.sanitize(label, 80)}</b><br>IP: {SecurityValidator.sanitize(a.get('ip_addr',''), 60)}<br>망: {SecurityValidator.sanitize(zone, 40)}",
                    "shape": "icon",
                    "icon": {
                        "face": "FontAwesome",
                        "code": style["code"],
                        "size": 50,
                        "color": style["color"],
                    },
                    "group": grp,
                    "zone": zone,
                }
            )
        return nodes

    # ---------- Mutations ----------
    def add_asset(self, payload: Dict[str, Any]) -> str:
        payload = self._normalize_payload_keys(payload)
        getv = lambda k: payload.get(k) if k in payload else payload.get(self.col_map.get(k, ""), "")

        ip = (getv("IP") or "").strip()
        if ip and not SecurityValidator.validate_ip(ip):
            raise ValueError("잘못된 IP 형식")

        is_dummy = bool(payload.get("is_dummy", False))
        if is_dummy:
            new_id = f"Dummy_{secrets.token_hex(4)}"
            manage_no = "임의장비"
        else:
            hostname = (getv("Hostname") or "").strip()
            manage_no = (getv("관리번호") or "").strip()
            new_id = hostname or manage_no or f"Asset_{secrets.token_hex(4)}"

        asset_name = (getv("자산명") or "").strip()
        asset_type = (getv("자산유형") or "").strip() or "Unknown"
        label = asset_name or new_id

        cols = ["id", "label", "group_name"]
        vals = [new_id, SecurityValidator.sanitize(label, 120), SecurityValidator.sanitize(asset_type, 80)]

        for k_kor, k_eng in self.col_map.items():
            if k_eng not in self.allowed_columns:
                continue
            raw = getv(k_kor)

            if k_kor == "IP":
                raw = ip
            elif k_kor == "도입금액":
                raw = SecurityValidator.normalize_price(str(raw))
            elif k_kor == "도입년월":
                raw = str(raw).strip()
                if raw and not SecurityValidator.validate_intro_date(raw):
                    raw2 = raw.replace("/", "-").replace(".", "-").strip()
                    if raw2.isdigit() and len(raw2) == 8:
                        raw2 = f"{raw2[0:4]}-{raw2[4:6]}-{raw2[6:8]}"
                    elif raw2.isdigit() and len(raw2) == 6:
                        raw2 = f"{raw2[0:4]}-{raw2[4:6]}"
                    if len(raw2) >= 10 and raw2[4] == "-" and raw2[7] == "-":
                        raw2 = raw2[:10]
                    if not SecurityValidator.validate_intro_date(raw2):
                        raise ValueError("도입년월 형식은 YYYY-MM 또는 YYYY-MM-DD 이어야 합니다.")
                    raw = raw2

            cols.append(k_eng)
            vals.append(SecurityValidator.sanitize(raw))

        if "manage_no" not in cols:
            cols.append("manage_no")
            vals.append(SecurityValidator.sanitize(manage_no))

        conn = get_conn(self.db_path)
        try:
            placeholders = ",".join(["?"] * len(cols))
            conn.execute(f"INSERT OR REPLACE INTO assets ({','.join(cols)}) VALUES ({placeholders})", vals)
            conn.commit()
        finally:
            conn.close()
        return new_id

    def _normalize_payload_keys(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        for k, v in (payload or {}).items():
            nk = str(k).strip().replace("\n", " ")
            nk = " ".join(nk.split())
            out[nk] = v
        return out

    def validate_assets_payloads(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        errors: List[Dict[str, Any]] = []
        valid_count = 0

        for idx, raw in enumerate(items or []):
            row_no = idx + 2
            try:
                item = self._normalize_payload_keys(raw)
                self._prepare_asset_row(item)
                valid_count += 1
            except Exception as e:
                msg = str(e) or "unknown error"
                field = ""
                if "IP" in msg: field = "IP"
                elif "도입년월" in msg: field = "도입년월"
                errors.append({"row": row_no, "field": field, "error": msg})

        return {
            "ok": True,
            "total": len(items or []),
            "valid_count": valid_count,
            "invalid_count": len(errors),
            "errors": errors
        }

    def _prepare_asset_row(self, payload: Dict[str, Any]) -> Tuple[str, List[Any]]:
        payload = self._normalize_payload_keys(payload)
        getv = lambda k: payload.get(k) if k in payload else payload.get(self.col_map.get(k, ""), "")

        ip = (getv("IP") or "").strip()
        if ip and not SecurityValidator.validate_ip(ip):
            raise ValueError("잘못된 IP 형식")

        is_dummy = bool(payload.get("is_dummy", False))
        if is_dummy:
            new_id = f"Dummy_{secrets.token_hex(4)}"
            manage_no = "임의장비"
        else:
            hostname = (getv("Hostname") or "").strip()
            manage_no = (getv("관리번호") or "").strip()
            new_id = hostname or manage_no or f"Asset_{secrets.token_hex(4)}"

        asset_name = (getv("자산명") or "").strip()
        asset_type = (getv("자산유형") or "").strip() or "Unknown"
        label = asset_name or new_id

        cols = ["id", "label", "group_name"]
        vals: List[Any] = [
            new_id,
            SecurityValidator.sanitize(label, 120),
            SecurityValidator.sanitize(asset_type, 80),
        ]

        for k_kor, k_eng in self.col_map.items():
            if k_eng not in self.allowed_columns:
                continue
            raw = getv(k_kor)

            if k_kor == "IP":
                raw = ip
            elif k_kor == "도입금액":
                raw = SecurityValidator.normalize_price(str(raw))
            elif k_kor == "도입년월":
                raw = str(raw).strip()
                if raw:
                    raw2 = raw.replace("/", "-").replace(".", "-").strip()
                    if raw2.isdigit() and len(raw2) == 8:
                        raw2 = f"{raw2[0:4]}-{raw2[4:6]}-{raw2[6:8]}"
                    elif raw2.isdigit() and len(raw2) == 6:
                        raw2 = f"{raw2[0:4]}-{raw2[4:6]}"
                    if len(raw2) >= 10 and raw2[4] == "-" and raw2[7] == "-":
                        raw2 = raw2[:10]
                    if not SecurityValidator.validate_intro_date(raw2):
                        raise ValueError("도입년월 형식은 YYYY-MM 또는 YYYY-MM-DD 이어야 합니다.")
                    raw = raw2

            vals.append(SecurityValidator.sanitize(raw))

        if "manage_no" in self.allowed_columns:
            vals.append(SecurityValidator.sanitize(manage_no))

        return new_id, vals

    def add_assets_bulk(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        cols = ["id", "label", "group_name"]
        cols += [k_eng for k_kor, k_eng in self.col_map.items() if k_eng in self.allowed_columns]
        if "manage_no" in self.allowed_columns:
            cols.append("manage_no")

        placeholders = ",".join(["?"] * len(cols))

        rows: List[List[Any]] = []

# 관리번호 기반 업데이트(업서트) 지원: 엑셀 업로드 시 동일 관리번호면 기존 장비를 업데이트
manage_nos = []
for raw0 in (items or []):
    mn0 = (raw0.get("관리번호") or raw0.get("manage_no") or raw0.get("관리 번호") or "").strip()
    if mn0:
        manage_nos.append(mn0)
existing_id_by_mn = {}
if manage_nos:
    conn0 = get_conn(self.db_path)
    try:
        q = "SELECT id, manage_no FROM assets WHERE manage_no IN (%s)" % (",".join(["?"]*len(manage_nos)))
        for r in conn0.execute(q, manage_nos).fetchall():
            existing_id_by_mn[r["manage_no"]] = r["id"]
    finally:
        conn0.close()

        errors: List[Dict[str, Any]] = []
        inserted = 0
        skipped = 0

        for idx, raw in enumerate(items or []):
            row_no = idx + 2
            try:
                _id, vals = self._prepare_asset_row(raw)
                mn = (raw.get("관리번호") or raw.get("manage_no") or raw.get("관리 번호") or "").strip()
                if mn and mn in existing_id_by_mn:
                    _id = existing_id_by_mn[mn]
                    vals[0] = _id

                mn = (raw.get('관리번호') or raw.get('manage_no') or raw.get('관리 번호') or '').strip()
                if mn and mn in existing_id_by_mn:
                    # 기존 장비 업데이트: 기존 id 재사용
                    _id = existing_id_by_mn[mn]
                    vals[0] = _id

                if len(vals) != len(cols):
                    raise ValueError("컬럼 매핑 길이가 일치하지 않습니다 (헤더/매핑 확인 필요)")
                rows.append(vals)
                inserted += 1
            except Exception as e:
                skipped += 1
                msg = str(e) or "unknown error"
                field = ""
                if "IP" in msg: field = "IP"
                elif "도입년월" in msg: field = "도입년월"
                errors.append({"row": row_no, "field": field, "error": msg})

        conn = get_conn(self.db_path)
        try:
            conn.execute("BEGIN")
            conn.executemany(
                f"INSERT OR REPLACE INTO assets ({','.join(cols)}) VALUES ({placeholders})",
                rows
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

        return {"ok": True, "inserted": inserted, "skipped": skipped, "errors": errors}

    def update_asset_field(self, asset_id: str, field_name: str, value: Any) -> Tuple[bool, Optional[str]]:
        if not field_name:
            return False, "field is required"

        db_col = self.col_map.get(field_name, None)
        if not db_col and field_name in self.allowed_columns:
            db_col = field_name

        if not db_col or db_col not in self.allowed_columns:
            return False, "field not allowed"

        raw = "" if value is None else str(value)

        if field_name == "IP" or db_col == "ip_addr":
            raw = raw.strip()
            if raw and not SecurityValidator.validate_ip(raw):
                return False, "invalid ip"
        if field_name == "도입금액" or db_col == "price":
            raw = SecurityValidator.normalize_price(raw)
        if field_name == "도입년월" or db_col == "intro_date":
            raw = raw.strip()
            if raw and not SecurityValidator.validate_intro_date(raw):
                if len(raw) == 8 and raw.isdigit():
                    raw = f"{raw[0:4]}-{raw[4:6]}-{raw[6:8]}"
                else:
                    return False, "invalid intro_date (YYYY-MM or YYYY-MM-DD)"

        safe = SecurityValidator.sanitize(raw)

        conn = get_conn(self.db_path)
        try:
            conn.execute(
                f"UPDATE assets SET {db_col}=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (safe, asset_id),
            )

            if field_name == "자산명" or db_col == "asset_name":
                conn.execute("UPDATE assets SET label=? WHERE id=?", (safe, asset_id))
            if field_name == "자산유형" or db_col == "asset_type":
                conn.execute("UPDATE assets SET group_name=? WHERE id=?", (safe, asset_id))

            conn.commit()
        finally:
            conn.close()
        return True, None

    def delete_asset(self, asset_id: str) -> None:
        conn = get_conn(self.db_path)
        try:
            conn.execute("DELETE FROM connections WHERE source_id=? OR target_id=?", (asset_id, asset_id))
            conn.execute("DELETE FROM software WHERE asset_id=?", (asset_id,))
            conn.execute("DELETE FROM manuals WHERE asset_id=?", (asset_id,))
            conn.execute("DELETE FROM assets WHERE id=?", (asset_id,))
            conn.commit()
        finally:
            conn.close()

    def disconnect_assets(self, src: str, tgt: str) -> Tuple[bool, Optional[str]]:
        """연결 삭제"""
        if not src or not tgt:
            return False, "source/target required"
        conn = get_conn(self.db_path)
        try:
            conn.execute(
                "DELETE FROM connections WHERE (source_id=? AND target_id=?) OR (source_id=? AND target_id=?)",
                (src, tgt, tgt, src),
            )
            conn.commit()
        finally:
            conn.close()
        return True, None

    def connect_assets(self, src: str, tgt: str, label: str = "연결됨") -> Tuple[bool, Optional[str]]:
        if not src or not tgt:
            return False, "source/target required"
        if src == tgt:
            return False, "same node not allowed"
        label = SecurityValidator.sanitize(label, 80)

        conn = get_conn(self.db_path)
        try:
            conn.execute(
                "INSERT OR IGNORE INTO connections (source_id, target_id, description) VALUES (?,?,?)",
                (src, tgt, label),
            )
            conn.commit()
        finally:
            conn.close()
        return True, None

    def get_asset_by_id(self, asset_id: str) -> Optional[Dict[str, Any]]:
        """단일 자산 상세 조회"""
        conn = get_conn(self.db_path)
        try:
            row = conn.execute("SELECT * FROM assets WHERE id=?", (asset_id,)).fetchone()
            if not row:
                return None
            a = dict(row)
            for k_kor, k_eng in self.col_map.items():
                a[k_kor] = a.get(k_eng, "") or ""

            sw = conn.execute(
                "SELECT id, sw_type, sw_name, sw_version FROM software WHERE asset_id=?",
                (a["id"],),
            ).fetchall()
            a["software"] = [dict(x) for x in sw]

            manuals = conn.execute(
                "SELECT id, doc_name, file_name, file_path FROM manuals WHERE asset_id=?",
                (a["id"],),
            ).fetchall()
            a["manuals"] = [dict(x) for x in manuals]

            conns = conn.execute(
                "SELECT source_id, target_id, description FROM connections WHERE source_id=? OR target_id=?",
                (a["id"], a["id"]),
            ).fetchall()
            a["connections"] = [dict(x) for x in conns]

            return a
        finally:
            conn.close()

    def create_backup(self, backup_dir: str) -> Optional[str]:
        try:
            os.makedirs(backup_dir, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = os.path.join(backup_dir, f"backup_{ts}.db")
            src = sqlite3.connect(self.db_path)
            dst = sqlite3.connect(backup_file)
            src.backup(dst)
            src.close()
            dst.close()
            return os.path.basename(backup_file)
        except Exception:
            return None
