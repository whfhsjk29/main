import html
import re
import secrets
from typing import Any, Dict

class SecurityValidator:
    IP_RE = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")
    DATE_RE = re.compile(r"^\d{4}-(\d{2})(-\d{2})?$")  # YYYY-MM or YYYY-MM-DD
    DIGITS_RE = re.compile(r"[^\d]")

    @staticmethod
    def random_secret() -> str:
        return secrets.token_hex(32)

    @staticmethod
    def sanitize(text: Any, max_len: int = 500) -> str:
        if text is None:
            return ""
        return html.escape(str(text).strip()[:max_len])

    @staticmethod
    def validate_ip(ip: str) -> bool:
        if not ip:
            return True
        if not SecurityValidator.IP_RE.match(ip):
            return False
        parts = ip.split(".")
        return all(0 <= int(p) <= 255 for p in parts)

    @staticmethod
    def normalize_price(value: str) -> str:
        # "1,000,000원" -> "1000000"
        if not value:
            return ""
        return SecurityValidator.DIGITS_RE.sub("", str(value))

    @staticmethod
    def validate_intro_date(value: str) -> bool:
        if not value:
            return True
        return bool(SecurityValidator.DATE_RE.match(value.strip()))

    @staticmethod
    def get_csrf(session_obj: Dict[str, Any]) -> str:
        if "csrf" not in session_obj:
            session_obj["csrf"] = secrets.token_hex(32)
        return session_obj["csrf"]

    @staticmethod
    def check_csrf(session_obj: Dict[str, Any], token: str) -> bool:
        if not token:
            return False
        return session_obj.get("csrf") == token
